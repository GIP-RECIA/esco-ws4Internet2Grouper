package org.esupportail.commons.mock;

import java.io.IOException;
import java.io.InputStream;

import org.apache.myfaces.custom.fileupload.UploadedFile;

public class MockUploadedFile implements UploadedFile {

	private static final long serialVersionUID = 6640876144695737829L;

	private InputStream stream;

	private String name;

	/**
	 * @param stream
	 * @param name
	 */
	public MockUploadedFile(
			final InputStream stream, 
			final String name) {
		super();
		this.stream = stream;
		this.name = name;
	}

	/**
	 * @see org.apache.myfaces.custom.fileupload.UploadedFile#getBytes()
	 */
	public byte[] getBytes() throws IOException {
		return null;
	}

	/**
	 * @see org.apache.myfaces.custom.fileupload.UploadedFile#getContentType()
	 */
	public String getContentType() {
		return null;
	}

	/**
	 * @see org.apache.myfaces.custom.fileupload.UploadedFile#getInputStream()
	 */
	public InputStream getInputStream() throws IOException {
		return stream;
	}

	/**
	 * @see org.apache.myfaces.custom.fileupload.UploadedFile#getName()
	 */
	public String getName() {
		return name;
	}

	/**
	 * @see org.apache.myfaces.custom.fileupload.UploadedFile#getSize()
	 */
	public long getSize() {
		return 0;
	}

}
