/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.utils; 

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.apache.myfaces.portlet.PortletUtil;
import org.esupportail.commons.exceptions.DownloadException;

/**
 * A class to retrieve beans.
 * 
 * Retrieving beans is based on the Spring config file since 
 */
public final class DownloadUtils {   
	
	/**
	 * Private constructor.
	 */
	private DownloadUtils() {
		throw new UnsupportedOperationException();
	}

	/**
	 * @param file 
	 * @return the contents of a file in a byte array.
	 * @throws IOException 
	 */
	public static byte[] getBytesFromFile(final File file) throws IOException {
		InputStream is = new FileInputStream(file);
		long length = file.length();
		if (length > Integer.MAX_VALUE) {
			throw new IOException("file [" + file.getName() + "] is too large for download");
		}
		byte[] bytes = new byte[(int) length];
		int offset = 0;
		int numRead = is.read(bytes, offset, bytes.length - offset);
		while (offset < bytes.length && numRead >= 0) {
			offset += numRead;
			numRead = is.read(bytes, offset, bytes.length - offset);
		}
		if (offset < bytes.length) {
			throw new IOException("could not completely read file [" + file.getName() + "]");
		}
		is.close();
		return bytes;
	}
	
	/**
	 * Set a download attribute for the download servlet.
	 * @param name 
	 * @param value 
	 */
	private static void setDownloadAttribute(
			final String name,
			final Object value) {
		ContextUtils.setGlobalSessionAttribute(name, value);
	}

	/**
	 * @param facesContext 
	 * @return the download URL (to redirect to).
	 * @throws DownloadException 
	 */
	private static String getDownloadUrl(
			final FacesContext facesContext) throws DownloadException {
		ExternalContext externalContext = facesContext.getExternalContext();
		String downloadUrl;
		if (PortletUtil.isPortletRequest(facesContext)) {
			downloadUrl = externalContext.getRequestContextPath() + "/download";
		} else {
			String path = externalContext.getRequestContextPath();
			downloadUrl = path + externalContext.getRequestServletPath().replaceFirst(
					"/stylesheets/[^/]*$", "/download");
			
		}
		return downloadUrl;
	}

	/**
	 * Set download data and redirect to the download URL.
	 * @param path
	 * @param filename 
	 * @throws DownloadException 
	 */
	public static void setDownload(
			final String path,
			final String filename) throws DownloadException {
		try {
			File file = new File(path);
			byte [] bytes;
			bytes = getBytesFromFile(file);
			setDownload(bytes, filename, null);
		} catch (Exception e) {
			throw new DownloadException(e);
		}
	}
	
	/**
	 * Set download data and redirect to the download URL.
	 * @param bytes
	 * @param filename 
	 * @param contentType 
	 * @throws DownloadException 
	 */
	public static void setDownload(
			final byte [] bytes,
			final String filename,
			final String contentType) throws DownloadException {
		try {
			FacesContext facesContext = FacesContext.getCurrentInstance();
			ExternalContext externalContext = facesContext.getExternalContext();
			setDownloadAttribute("downloadData", bytes);
			if (contentType != null) {
				setDownloadAttribute("downloadContentType", contentType);
			}
			if (filename != null) {
				setDownloadAttribute("downloadFilename", filename);
			}
			externalContext.redirect(getDownloadUrl(facesContext));
			facesContext.responseComplete();
		} catch (Exception e) {
			throw new DownloadException(e);
		}
	}

	/**
	 * Set download data and redirect to the download URL.
	 * @param bytes
	 * @throws DownloadException 
	 */
	public static void setDownload(
			final byte [] bytes) throws DownloadException {
		setDownload(bytes, null, null);
	}

	/**
	 * Set download data and redirect to the download URL.
	 * @param file
	 * @throws DownloadException 
	 */
	public static void setDownload(
			final File file) throws DownloadException {
		try {
			setDownload(getBytesFromFile(file), file.getName(), null);
		} catch (DownloadException e) {
			throw e;
		} catch (Exception e) {
			throw new DownloadException(e);
		}
	}

	/**
	 * Set download data and redirect to the download URL.
	 * @param path
	 * @throws DownloadException 
	 */
	public static void setDownload(
			final String path) throws DownloadException {
		setDownload(new File(path));
	}

}
