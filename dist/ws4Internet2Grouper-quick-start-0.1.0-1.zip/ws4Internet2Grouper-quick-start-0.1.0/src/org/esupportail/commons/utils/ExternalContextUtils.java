/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.utils; 

import org.esupportail.commons.services.logging.Logger;
import org.esupportail.commons.services.logging.LoggerImpl;

/**
 * A deprecated class.
 */
public class ExternalContextUtils {

	/**
	 * A logger.
	 */
	private static final Logger LOG = new LoggerImpl(ExternalContextUtils.class);

	/**
	 * Private constructor.
	 */
	private ExternalContextUtils() {
		throw new UnsupportedOperationException();
	}

	/**
	 * @param name
	 * @return .
	 * @deprecated
	 */
	@Deprecated
	public static Object getRequestVar(
			@SuppressWarnings("unused")
			final String name) {
		LOG.warn("ExternalContextUtils is deprecated, use ContextUtils.getRequestAttribute()!");
		return ContextUtils.getRequestAttribute(name);
	}

	/**
	 * @param name
	 * @param value
	 * @deprecated
	 */
	@Deprecated
	public static void setRequestVar(
			final String name,
			final Object value) {
		LOG.warn("ExternalContextUtils is deprecated, use ContextUtils.setRequestAttribute()!");
		ContextUtils.setRequestAttribute(name, value);
	}

	/**
	 * @param name
	 * @return .
	 * @deprecated
	 */
	@Deprecated
	public static Object getSessionVar(
			final String name) {
		LOG.warn("ExternalContextUtils is deprecated, use ContextUtils.getSessionAttribute()!");
		return ContextUtils.getSessionAttribute(name);
	}

	/**
	 * @param name
	 * @param value
	 * @deprecated
	 */
	@Deprecated
	public static void setSessionVar(
			final String name,
			final Object value) {
		LOG.warn("ExternalContextUtils is deprecated, use ContextUtils.setSessionAttribute()!");
		ContextUtils.setSessionAttribute(name, value);
	}

}
