/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.smtp;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Vector;

import javax.mail.internet.InternetAddress;

import org.esupportail.commons.services.logging.Logger;
import org.esupportail.commons.services.logging.LoggerImpl;
import org.esupportail.commons.utils.Assert;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

/**
 * A simple implementation of SmtpService.
 * 
 * See /properties/smtp/smtp-example.xml.
 */
public class SimpleSmtpServiceImpl extends AbstractSmtpService implements InitializingBean {
	
	/**
	 * The default encoding charset.
	 */
	private static final String DEFAULT_CHARSET = "utf-8";
	
	/**
	 * A logger.
	 */
	private final Logger logger = new LoggerImpl(getClass());

	/**
	 * The smtpServers to use.
	 */
	private List<SmtpServer> servers;

	/**
	 * The 'From' address to use.
	 */
	private InternetAddress fromAddress;
	
	/**
	 * The address to which _all_ the emails should be sent (if null, all the
	 * emails are sent normally).
	 */
	private InternetAddress interceptAddress;

	/**
	 * The recipient of the test emails.
	 */
	private InternetAddress testAddress;
	
	/**
	 * The charset used to encode the headers.
	 */
	private String charset;

	/**
	 * Constructor.
	 */
	public SimpleSmtpServiceImpl() {
		super();
		this.servers = null;
		this.fromAddress = null;
		this.interceptAddress = null;
		this.charset = null;
	}

	/**
	 * Set the default charset.
	 */
	public void setDefaultCharset() {
		setCharset(DEFAULT_CHARSET);
	}

	/**
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	public void afterPropertiesSet() throws Exception {
		if (CollectionUtils.isEmpty(servers)) {
			logger.info(getClass() + ": no SMTP server set, '" + SmtpServer.DEFAULT_HOST + ":" 
					+ SmtpServer.DEFAULT_PORT + "' will be used");
			SmtpServer server = new SmtpServer();
			server.setDefaultHost();
			server.setDefaultPort();
			if (this.servers == null) {
				this.servers = new Vector<SmtpServer>();
			}
			this.servers.add(server);
		}
		Assert.notNull(this.fromAddress, 
				"property fromAddress of class " + this.getClass().getName() + " can not be null");
		if (!StringUtils.hasText(charset)) {
			logger.info(getClass() + ": no encoding charset set, '" + DEFAULT_CHARSET + "' will be used");
			setDefaultCharset();
		}
		if (testAddress == null) {
			logger.info(getClass() + ": no testAddress attribute set, target ldap-smtp will not work."); 
		}
	}

	/**
	 * @return the real recipient of an email.
	 * @param to
	 * @param intercept
	 */
	protected InternetAddress getRealRecipient(final InternetAddress to, final boolean intercept) {
		InternetAddress recipient;
		if (intercept && this.interceptAddress != null) {
			try {
				recipient = new InternetAddress(
						interceptAddress.getAddress(),
						this.interceptAddress.getPersonal() + " (normally sent to " 
						+ to.getAddress() + ")");
			} catch (UnsupportedEncodingException e) {
				throw new SmtpException("could not send mail to '" + to.getAddress() + "'", e);
			}
		} else {
			recipient = to;
		}
		return recipient;
	}	
	
	/**
	 * Send an email.
	 * @param to
	 * @param subject
	 * @param htmlBody
	 * @param textBody
	 * @param files 
	 * @param intercept
	 */
	protected void send(
			final InternetAddress to, 
			final String subject, 
			final String htmlBody, 
			final String textBody,
			final List<File> files,
			final boolean intercept) {
		InternetAddress recipient = getRealRecipient(to, intercept);
		SmtpUtils.sendEmail(
				this.servers, this.fromAddress, recipient, subject, 
				htmlBody, textBody, files, this.charset);
	}
	
	/**
	 * Send an email to, cc, bcc.
	 * @param tos
	 * @param ccs
	 * @param bccs
	 * @param subject
	 * @param htmlBody
	 * @param textBody
	 * @param files
	 * @param intercept
	 */
	protected void sends(
			final InternetAddress[] tos,
			final InternetAddress[] ccs, 
			final InternetAddress[] bccs,  
			final String subject, 
			final String htmlBody, 
			final String textBody,
			final List<File> files,
			final boolean intercept) {
	
		SmtpUtils.sendEmailtocc(
				this.servers, this.fromAddress, tos, ccs, bccs,
				subject, htmlBody, textBody, files, this.charset);
	}
	
	
	/**
	 * @see org.esupportail.commons.services.smtp.SmtpService#send(
	 * javax.mail.internet.InternetAddress, java.lang.String, java.lang.String, java.lang.String)
	 */
	public void send(
			final InternetAddress to, 
			final String subject, 
			final String htmlBody, 
			final String textBody) {
		send(to, subject, htmlBody, textBody, null, true);
	}	
	
	
	/**
	 * @see org.esupportail.commons.services.smtp.SmtpService#send(
	 * javax.mail.internet.InternetAddress, java.lang.String, java.lang.String, java.lang.String, java.util.List)
	 */
	public void send(
			final InternetAddress to, 
			final String subject, 
			final String htmlBody, 
			final String textBody,
			final List<File> files) {
		send(to, subject, htmlBody, textBody, files, true);
	}	
	
	/**
	 * @see org.esupportail.commons.services.smtp.SmtpService#sendtocc
	 * (javax.mail.internet.InternetAddress[], 
	 * javax.mail.internet.InternetAddress[], 
	 * javax.mail.internet.InternetAddress[], 
	 * java.lang.String, 
	 * java.lang.String, java.lang.String, java.util.List)
	 */
	public void sendtocc(
			final InternetAddress[] tos,
			final InternetAddress[] ccs, 
			final InternetAddress[] bccs, 
			final String subject, 
			final String htmlBody, 
			final String textBody, 
			final List<File> files) {
		sends(tos, ccs, bccs, subject, htmlBody, textBody, files , false);
		
	}
	
	/**
	 * @see org.esupportail.commons.services.smtp.SmtpService#sendDoNotIntercept(
	 * javax.mail.internet.InternetAddress, java.lang.String, java.lang.String, java.lang.String)
	 */
	public void sendDoNotIntercept(
			final InternetAddress to, 
			final String subject, 
			final String htmlBody, 
			final String textBody) {
		send(to, subject, htmlBody, textBody, null, false);
	}
	
	
	
	/**
	 * @see org.esupportail.commons.services.smtp.SmtpService#sendDoNotIntercept(
	 * javax.mail.internet.InternetAddress, java.lang.String, java.lang.String, java.lang.String, java.util.List)
	 */
	public void sendDoNotIntercept(
			final InternetAddress to,
			final String subject,
			final String htmlBody,
			final String textBody,
			final List<File> files) {
		send(to, subject, htmlBody, textBody, files, false);	
	}
	
	/**
	 * @see org.esupportail.commons.services.smtp.AbstractSmtpService#supportsTest()
	 */
	@Override
	public boolean supportsTest() {
		return true;
	}

	/**
	 * @see org.esupportail.commons.services.smtp.AbstractSmtpService#test()
	 */
	@Override
	public void test() {
		if (testAddress == null) {
			logger.error("can not test the SMTP connection when property testAddress is not set, " 
					+ "edit configuration file smtp.xml.");
			return;
		}
		sendDoNotIntercept(testAddress, "SMTP test", "<p>This is a <b>test</b>.</p>", "This is a test.");
	}

	/**
	 * @return The servers.
	 */
	public List<SmtpServer> getServers() {
		return this.servers;
	}
	/**
	 * @param servers The servers to set.
	 */
	public void setServers(
			final List<SmtpServer> servers) {
		this.servers = servers;
	}
	/**
	 * @return The fromAddress.
	 */
	public InternetAddress getFromAddress() {
		return this.fromAddress;
	}
	/**
	 * @param fromAddress The fromAddress to set.
	 */
	public void setFromAddress(
			final InternetAddress fromAddress) {
		this.fromAddress = fromAddress;
	}
	/**
	 * @return The interceptAddress.
	 */
	public InternetAddress getInterceptAddress() {
		return this.interceptAddress;
	}
	/**
	 * @param interceptAddress The interceptAddress to set.
	 */
	public void setInterceptAddress(
			final InternetAddress interceptAddress) {
		this.interceptAddress = interceptAddress;
	}
	/**
	 * @return The charset.
	 */
	public String getCharset() {
		return this.charset;
	}
	/**
	 * @param charset The charset to set.
	 */
	public void setCharset(final String charset) {
		this.charset = charset;
	}

	/**
	 * @return the testAddress
	 */
	public InternetAddress getTestAddress() {
		return testAddress;
	}

	/**
	 * @param testAddress the testAddress to set
	 */
	public void setTestAddress(final InternetAddress testAddress) {
		this.testAddress = testAddress;
	}

}
