/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.urlGeneration; 

import java.util.Map;

import org.esupportail.commons.utils.Assert;

/**
 * A bean to generate URLs to the application.
 */
public class ServletUrlGeneratorImpl extends AbstractUrlGenerator {

	/**
	 * The name of the parameter for servlets.
	 */
	public static final String ARGS_PARAM = "args";
	
	/**
	 * The servlet URL.
	 */
	private String servletUrl;
	
	/**
	 * Bean constructor.
	 */
	public ServletUrlGeneratorImpl() {
		super();
	}
	
	/**
	 * @see org.esupportail.commons.services.urlGeneration.AbstractUrlGenerator#afterPropertiesSet()
	 */
	@Override
	public void afterPropertiesSet() {
		super.afterPropertiesSet();
		Assert.notNull(servletUrl, "property servletUrl of class " 
					+ this.getClass().getName() + " can not be null");
	}

	/**
	 * @param useCas 
	 * @param params 
	 * @return a link to the application with parameters.
	 */
	@Override
	protected String url(
			final boolean useCas,
			final Map<String, String> params) {
		if (useCas && getCasLoginUrl() == null) {
			throw new UnsupportedOperationException("casLoginUrl is not set, can generate URLs via CAS");
		}
		String arg = encodeParamsToArg(params);
		String url = getServletUrl();
		if (arg != null) {
			url = url + "?" + ARGS_PARAM 
			+ "=" + org.esupportail.commons.utils.strings.StringUtils.utf8UrlEncode(arg);
		}
		if (useCas) {
			url = String.format(getCasLoginUrl(), url);
		}
		return url;
	}

	/**
	 * @return the servletUrl
	 */
	protected String getServletUrl() {
		return servletUrl;
	}

	/**
	 * @param servletUrl the servletUrl to set
	 */
	public void setServletUrl(final String servletUrl) {
		this.servletUrl = servletUrl;
	}

}
