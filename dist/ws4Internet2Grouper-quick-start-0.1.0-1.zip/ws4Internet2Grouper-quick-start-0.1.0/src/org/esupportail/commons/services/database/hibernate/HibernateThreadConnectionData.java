/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.database.hibernate;

import org.esupportail.commons.services.logging.Logger;
import org.esupportail.commons.services.logging.LoggerImpl;
import org.esupportail.commons.utils.BeanUtils;
import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.orm.hibernate3.SessionHolder;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/**
 * A class to store the Hibernate connexion data to have a single session
 * per thread.
 */

public class HibernateThreadConnectionData {

	/**
	 * A logger.
	 */
	private final Logger logger = new LoggerImpl(HibernateThreadConnectionData.class);

	/**
	 * A flag set to true if only participating.
	 */
	private boolean participate;
	
	/**
	 * The hibernate session.
	 */
	private Session session;
	
	/**
	 * The name of the session factory bean.
	 */
	private String sessionFactoryBeanName;
	
	/**
	 * The session factory.
	 */
	private SessionFactory sessionFactory;
	
	/**
	 * Bean constructor.
	 */
	HibernateThreadConnectionData(final String sessionFactoryBeanName) {
		super();
		sessionFactory = null;
		session = null;
		participate = false;
		this.sessionFactoryBeanName = sessionFactoryBeanName;
	}
	
	/**
	 * Open the session.
	 */
	void openSession() {
		if (logger.isDebugEnabled()) {
			logger.debug("openSession()");
		}
		sessionFactory = (SessionFactory) BeanUtils.getBean(sessionFactoryBeanName);
		if (TransactionSynchronizationManager.hasResource(sessionFactory)) {
			participate = true;
			return;
		}
		session = SessionFactoryUtils.getSession(sessionFactory, true);
		session.setFlushMode(FlushMode.ALWAYS);
		TransactionSynchronizationManager.bindResource(sessionFactory, new SessionHolder(session));
	}

	/**
	 * Begin a transaction.
	 */
	void beginTransaction() {
		if (participate) {
			return;
		}
		if (session != null) {
			session.beginTransaction();
		}
	}

	/**
	 * End a transaction.
	 */
	void endTransaction(final boolean commit) {
		if (participate) {
			return;
		}
		if (session != null) {
			if (session.isOpen()) {
				Transaction transaction = session.getTransaction();
				if (transaction != null && transaction.isActive()) {
					if (commit) {
						transaction.commit();
					} else {
						transaction.rollback();
					}
				}
			}
		}
	}

	/**
	 * Close the session.
	 */
	void closeSession() {
		if (logger.isDebugEnabled()) {
			logger.debug("closeSession()");
		}
		if (participate) {
			return;
		}
		TransactionSynchronizationManager.unbindResource(sessionFactory);
		if (session != null) {
			if (session.isOpen()) {
				Transaction transaction = session.getTransaction();
				if (transaction != null && transaction.isActive()) {
					transaction.rollback();
				}
				SessionFactoryUtils.releaseSession(session, sessionFactory);
			}
		}
		session = null;
	}

}
