/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.ldap;

import org.springframework.ldap.support.filter.AbstractFilter;

/**
 * A LdapTemplate filter, build with a string (that represents an already-encoded filter).
 */
public class StringFilter extends AbstractFilter {
	
	/**
	 * The filter string.
	 */
	private String filterExpr;

	/**
	 * Bean constructor.
	 * @param filterExpr an already-encoded LDAP filter
	 */
	public StringFilter(final String filterExpr) {
		super();
		this.filterExpr = "(" + filterExpr + ")";
	}

	/**
	 * @see org.springframework.ldap.support.filter.AbstractFilter#encode(java.lang.StringBuffer)
	 */
	@Override
	public StringBuffer encode(final StringBuffer buff) {
		buff.append(filterExpr);
		return buff;
	}

}
