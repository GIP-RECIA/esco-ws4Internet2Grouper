/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.database.hibernate;

import org.esupportail.commons.exceptions.ConfigException;
import org.esupportail.commons.utils.Assert;
import org.esupportail.commons.utils.BeanUtils;

/**
 * An abstract class for non updatable database managers.
 */
public class UpgradableHibernateDatabaseManagerImpl extends BasicHibernateDatabaseManagerImpl {

	/**
	 * The name of the session factory bean (create mode).
	 */
	private String createSessionFactoryBeanName;
	
	/**
	 * The name of the session factory bean (upgrade mode).
	 */
	private String upgradeSessionFactoryBeanName;
	
	/**
	 * Bean constructor.
	 */
	public UpgradableHibernateDatabaseManagerImpl() {
		super();
	}

	/**
	 * @see org.esupportail.commons.services.database.hibernate.BasicHibernateDatabaseManagerImpl
	 * #afterPropertiesSet()
	 */
	@Override
	public void afterPropertiesSet() throws Exception {
		super.afterPropertiesSet();
		Assert.hasText(createSessionFactoryBeanName, 
				"property [createSessionFactoryBeanName] of class [" 
				+ getClass().getName() + "] can not be null");
		Assert.hasText(upgradeSessionFactoryBeanName, 
				"property [upgradeSessionFactoryBeanName] of class [" 
				+ getClass().getName() + "] can not be null");
	}

	/**
	 * @see org.esupportail.commons.services.database.AbstractBasicDatabaseManager#isUpgradable()
	 */
	@Override
	public boolean isUpgradable() {
		return true;
	}

	/**
	 * @see org.esupportail.commons.services.database.AbstractBasicDatabaseManager#create()
	 */
	@Override
	public void create() {
		BeanUtils.getBean(createSessionFactoryBeanName);
	}

	/**
	 * @see org.esupportail.commons.services.database.AbstractBasicDatabaseManager#upgrade()
	 */
	@Override
	public void upgrade() {
		BeanUtils.getBean(upgradeSessionFactoryBeanName);
	}

	/**
	 * @param createSessionFactoryBeanName the createSessionFactoryBeanName to set
	 */
	public void setCreateSessionFactoryBeanName(final String createSessionFactoryBeanName) {
		this.createSessionFactoryBeanName = createSessionFactoryBeanName;
	}

	/**
	 * @param upgradeSessionFactoryBeanName the upgradeSessionFactoryBeanName to set
	 */
	public void setUpgradeSessionFactoryBeanName(final String upgradeSessionFactoryBeanName) {
		this.upgradeSessionFactoryBeanName = upgradeSessionFactoryBeanName;
	}

	/**
	 * @see org.esupportail.commons.services.database.hibernate.BasicHibernateDatabaseManagerImpl#isTransactionnal()
	 */
	@Override
	public boolean isTransactionnal() {
		return true;
	}

	/**
	 * @see org.esupportail.commons.services.database.hibernate.BasicHibernateDatabaseManagerImpl#setTransactionnal(
	 * boolean)
	 */
	@Override
	public void setTransactionnal(final boolean transactionnal) {
		throw new ConfigException(
				"property [" + transactionnal + "] is always true for class [" 
				+ getClass().getName() + "]");
	}

}
