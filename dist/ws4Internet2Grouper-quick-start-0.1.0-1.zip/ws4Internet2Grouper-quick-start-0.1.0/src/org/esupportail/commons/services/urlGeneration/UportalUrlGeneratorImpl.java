/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.urlGeneration; 

import java.util.Map;

import org.esupportail.commons.utils.Assert;

/**
 * A bean to generate URLs to the application.
 */
public class UportalUrlGeneratorImpl extends AbstractUrlGenerator {

	/**
	 * The name of the parameter that uPortal uses to pass parameters to channels.
	 */
	public static final String ARGS_PARAM = "uP_args";
	
	/**
	 * The uP_fname uPortal parameter.
	 */
	protected static final String UPORTAL_FNAME_PARAM = "uP_fname";
	
	/**
	 * The uPortal URL.
	 */
	private String uportalUrl;
	
	/**
	 * The uPortal funtionnal name (the name used to publish the uPortal channel of the portlet).
	 */
	private String uportalFunctionnalName;
	
	/**
	 * Bean constructor.
	 */
	public UportalUrlGeneratorImpl() {
		super();
	}
	
	/**
	 * @see org.esupportail.commons.services.urlGeneration.AbstractUrlGenerator#afterPropertiesSet()
	 */
	@Override
	public void afterPropertiesSet() {
		Assert.notNull(uportalFunctionnalName, "property uportalFunctionnalName of class " 
				+ this.getClass().getName() + " can not be null");
		Assert.notNull(uportalUrl, "property uportalUrl of class " 
				+ this.getClass().getName() + " can not be null");
	}

	/**
	 * @see org.esupportail.commons.services.urlGeneration.AbstractUrlGenerator#url(boolean, java.util.Map)
	 */
	@Override
	protected String url(
			final boolean useCas,
			final Map<String, String> params) {
		if (useCas && getCasLoginUrl() == null) {
			throw new UnsupportedOperationException("casLoginUrl is not set, can generate URLs via CAS");
		}
		String arg = encodeParamsToArg(params);
		String url = getUportalUrl() + "?" + UPORTAL_FNAME_PARAM + "=" + getUportalFunctionnalName();
		if (arg != null) {
			url = url + "&" + ARGS_PARAM 
			+ "=" + org.esupportail.commons.utils.strings.StringUtils.utf8UrlEncode(arg);
		}
		if (useCas) {
			url = String.format(getCasLoginUrl(), 
					org.esupportail.commons.utils.strings.StringUtils.utf8UrlEncode(url));
		}
		return url;
	}

	/**
	 * @return the uportalFunctionnalName
	 */
	protected String getUportalFunctionnalName() {
		return uportalFunctionnalName;
	}

	/**
	 * @param uportalFunctionnalName the uportalFunctionnalName to set
	 */
	public void setUportalFunctionnalName(final String uportalFunctionnalName) {
		this.uportalFunctionnalName = uportalFunctionnalName;
	}

	/**
	 * @return the uportalUrl
	 */
	protected String getUportalUrl() {
		return uportalUrl;
	}

	/**
	 * @param uportalUrl the uportalUrl to set
	 */
	public void setUportalUrl(final String uportalUrl) {
		this.uportalUrl = uportalUrl;
	}

}
