/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.ldap;

/**
 * This exception is thrown when usingg a bad LDAP filter.
 */
public class LdapBadFilterException extends LdapException {

	/**
	 * The id for serialization.
	 */
	private static final long serialVersionUID = 5173114646165430729L;

	/**
	 * Bean constructor.
	 */
	public LdapBadFilterException() {
		super();
	}

	/**
	 * Bean constructor.
	 * @param message
	 */
	public LdapBadFilterException(final String message) {
		super(message);
	}

	/**
	 * Bean constructor.
	 * @param cause
	 */
	public LdapBadFilterException(final Exception cause) {
		super(cause);
	}

	/**
	 * Bean constructor.
	 * @param message
	 * @param cause
	 */
	public LdapBadFilterException(final String message, final Exception cause) {
		super(message, cause);
	}

}
