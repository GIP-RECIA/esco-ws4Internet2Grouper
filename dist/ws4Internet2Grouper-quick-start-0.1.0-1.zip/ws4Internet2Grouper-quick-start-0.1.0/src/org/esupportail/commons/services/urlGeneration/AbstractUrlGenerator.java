/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.urlGeneration; 

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.esupportail.commons.services.exceptionHandling.ExceptionUtils;
import org.esupportail.commons.services.logging.Logger;
import org.esupportail.commons.services.logging.LoggerImpl;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.StringUtils;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * An abstract class that implements UrlGenerator.
 */
public abstract class AbstractUrlGenerator implements UrlGenerator, InitializingBean {

	/**
	 * The separator between parameters.
	 */
	public static final String PARAMS_SEPARATOR = "&";
	
	/**
	 * The separator between name and value.
	 */
	public static final String NAME_VALUE_SEPARATOR = "=";
	
	/**
	 * A logger.
	 */
	private final Logger logger = new LoggerImpl(getClass());
	
	/**
	 * The CAS URL.
	 */
	private String casLoginUrl;
	
	/**
	 * Bean constructor.
	 */
	protected AbstractUrlGenerator() {
		super();
	}
	
 	/**
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	public void afterPropertiesSet() {
		if (!StringUtils.hasText(casLoginUrl)) {
			casLoginUrl = null;
			logger.warn("casLoginUrl is null, URLs via CAS will not be available");
		}
	}

	/**
	 * Encode parameters into an argument.
	 * @param params
	 * @return the argument
	 */
	public static String encodeParamsToArg(
			final Map<String, String> params) {
		String arg = "";
		if (params != null && !params.isEmpty()) {
			String separator = "";
			for (String name : params.keySet()) {
				arg = arg + separator + name + NAME_VALUE_SEPARATOR + params.get(name);
				separator = PARAMS_SEPARATOR;
			}
		}
		String encodedArg = new BASE64Encoder().encode(arg.getBytes()); 
		return encodedArg;
	}

	/**
	 * Decode arguments into parameters.
	 * @param arg
	 * @return the parameters
	 */
	public static Map<String, String> decodeArgToParams(
			final String arg) {
		if (arg == null) {
			return null;
		}
		String decodedArg;
		try {
			decodedArg = new String(new BASE64Decoder().decodeBuffer(arg));
		} catch (IOException e) {
			ExceptionUtils.catchException(e);
			return null;
		}
		Map<String, String> params = new HashMap<String, String>(); 
		for (String param : decodedArg.split(PARAMS_SEPARATOR)) {
			String[] nameValueArray = param.split(NAME_VALUE_SEPARATOR, 2);
			if (nameValueArray.length == 2) {
				params.put(nameValueArray[0], nameValueArray[1]);
			} else {
				params.put(nameValueArray[0], "");
			}
		}
		return params;
	}

	/**
	 * @param useCas 
	 * @param params 
	 * @return a link to the application with parameters.
	 */
	protected abstract String url(
			final boolean useCas,
			final Map<String, String> params);

	/**
	 * @see org.esupportail.commons.services.urlGeneration.UrlGenerator#url(java.util.Map)
	 */
	public String url(
			final Map<String, String> params) {
		return url(false, params);
	}

	/**
	 * @see org.esupportail.commons.services.urlGeneration.UrlGenerator#url()
	 */
	public String url() {
		return url(null);
	}

	/**
	 * @see org.esupportail.commons.services.urlGeneration.UrlGenerator#urlViaCas(java.util.Map)
	 */
	public String urlViaCas(
			final Map<String, String> params) {
		return url(true, params);
	}

	/**
	 * @see org.esupportail.commons.services.urlGeneration.UrlGenerator#urlViaCas()
	 */
	public String urlViaCas() {
		return urlViaCas(null);
	}

	/**
	 * @return the casLoginUrl
	 */
	protected String getCasLoginUrl() {
		return casLoginUrl;
	}

	/**
	 * @param casLoginUrl the casLoginUrl to set
	 */
	public void setCasLoginUrl(final String casLoginUrl) {
		this.casLoginUrl = casLoginUrl;
	}

}
