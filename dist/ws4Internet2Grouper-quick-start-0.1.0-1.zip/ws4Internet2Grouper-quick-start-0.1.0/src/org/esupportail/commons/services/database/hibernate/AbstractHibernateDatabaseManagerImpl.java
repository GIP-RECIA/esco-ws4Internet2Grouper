/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.database.hibernate;

import org.esupportail.commons.services.database.AbstractBasicDatabaseManager;
import org.esupportail.commons.utils.Assert;
import org.springframework.beans.factory.InitializingBean;

/**
 * An abstract class for non updatable database managers.
 */
public abstract class AbstractHibernateDatabaseManagerImpl 
extends AbstractBasicDatabaseManager 
implements InitializingBean {

	/**
	 * Holds the thread data.
	 */
	private static ThreadLocal<HibernateThreadData> ts = new ThreadLocal<HibernateThreadData>();
	
	/**
	 * The name of the session factory bean (normal mode).
	 */
	private String sessionFactoryBeanName;
	
	/**
	 * Bean constructor.
	 */
	public AbstractHibernateDatabaseManagerImpl() {
		super();
	}

	/**
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	public void afterPropertiesSet() throws Exception {
		Assert.hasText(sessionFactoryBeanName, 
				"property [sessionFactoryBeanName] of class [" 
				+ getClass().getName() + "] can not be null");
	}

	/**
	 * @see org.esupportail.commons.services.database.DatabaseManager#openSession()
	 */
	public void openSession() {
		HibernateThreadData td = ts.get();
		if (td == null) {
			td = new HibernateThreadData();
			ts.set(td);
		}
		td.openSession(sessionFactoryBeanName);
	}

	/**
	 * @see org.esupportail.commons.services.database.DatabaseManager#beginTransaction()
	 */
	public void beginTransaction() {
		if (!isTransactionnal()) {
			return;
		}
		HibernateThreadData td = ts.get();
		if (td != null) {
			td.beginTransaction(sessionFactoryBeanName);
		}
	}

	/**
	 * @see org.esupportail.commons.services.database.DatabaseManager#endTransaction(boolean)
	 */
	public void endTransaction(
			final boolean commit) {
		if (!isTransactionnal()) {
			return;
		}
		HibernateThreadData td = ts.get();
		if (td != null) {
			td.endTransaction(sessionFactoryBeanName, commit);
		}
	}

	/**
	 * @see org.esupportail.commons.services.database.DatabaseManager#closeSession()
	 */
	public void closeSession() {
		HibernateThreadData td = ts.get();
		if (td != null) {
			td.closeSession(sessionFactoryBeanName);
		}
	}

	/**
	 * @see org.esupportail.commons.services.database.DatabaseManager#test()
	 */
	public void test() {
		openSession();
		beginTransaction();
		endTransaction(false);
		closeSession();
	}

	/**
	 * @param sessionFactoryBeanName the sessionFactoryBeanName to set
	 */
	public void setSessionFactoryBeanName(final String sessionFactoryBeanName) {
		this.sessionFactoryBeanName = sessionFactoryBeanName;
	}

}
