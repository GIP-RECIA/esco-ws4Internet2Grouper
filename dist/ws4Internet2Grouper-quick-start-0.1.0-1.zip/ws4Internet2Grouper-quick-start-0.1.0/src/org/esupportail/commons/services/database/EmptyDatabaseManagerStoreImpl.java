/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.database;

import java.util.List;


/**
 * An empty implementation of the database manager store.
 */
public class EmptyDatabaseManagerStoreImpl extends AbstractDatabaseManagerStore {

	/**
	 * Bean constructor.
	 */
	public EmptyDatabaseManagerStoreImpl() {
		super();
	}

	/**
	 * @see org.esupportail.commons.services.database.AbstractDatabaseManagerStore#getDatabaseManagers()
	 */
	@Override
	protected List<DatabaseManager> getDatabaseManagers() {
		return null;
	}

}
