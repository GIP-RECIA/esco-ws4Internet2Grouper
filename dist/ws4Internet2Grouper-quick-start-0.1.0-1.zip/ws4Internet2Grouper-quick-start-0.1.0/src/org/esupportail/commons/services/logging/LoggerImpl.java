/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.logging; 

import java.io.Serializable;
import java.util.List;

import org.apache.commons.logging.LogFactory;
import org.esupportail.commons.services.exceptionHandling.ExceptionUtils;

/**
 * A class based on Jakarta commons-logging that provides logging features.
 */
public class LoggerImpl implements Logger, Serializable {

	/**
	 * For serialize.
	 */
	private static final long serialVersionUID = 1256964268439590331L;

	/**
	 * The null string.
	 */
	private static final String NULL = "null";
	
	/**
	 * a static physical logger.
	 */
	private org.apache.commons.logging.Log logger;

	/**
	 * Constructor.
	 * @param logClass the class the logger will be used by.
	 */
	@SuppressWarnings("unchecked")
	public LoggerImpl(final Class logClass) {
		logger = LogFactory.getLog(logClass);
	}

	/**
	 * Constructor.
	 * @param category
	 */
	public LoggerImpl(final String category) {
		logger = LogFactory.getLog(category);
	}

	/**
	 * @see org.esupportail.commons.services.logging.Logger#isTraceEnabled()
	 */
	public boolean isTraceEnabled() {
		return logger.isTraceEnabled();
	}

	/**
	 * @see org.esupportail.commons.services.logging.Logger#trace(java.lang.StringBuffer)
	 */
	public void trace(final StringBuffer sb) {
		trace(sb.toString());
	}

	/**
	 * @see org.esupportail.commons.services.logging.Logger#trace(java.lang.String)
	 */
	public void trace(final String str) {
		if (str == null) {
			logger.trace(NULL);
		} else {
			String [] lines = str.split("\n");
			for (int i = 0; i < lines.length; i++) {
				logger.trace(lines[i]);
			}
		}
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#trace(java.lang.Exception)
	 */
	public void trace(final Exception e) {
		trace(ExceptionUtils.getPrintableStackTrace(e));
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#trace(java.lang.String, java.lang.Exception)
	 */
	public void trace(final String str, final Exception e) {
		trace(str);
		trace(e);
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#trace(java.lang.StringBuffer, java.lang.Exception)
	 */
	public void trace(final StringBuffer sb, final Exception e) {
		trace(sb.toString(), e);
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#trace(java.util.List)
	 */
	public void trace(final List<String> list) {
		for (String string : list) {
			trace(string);
		}
	}

	/**
	 * @see org.esupportail.commons.services.logging.Logger#trace(java.util.List, java.lang.Exception)
	 */
	public void trace(final List<String> list, final Exception e) {
		trace(list);
		trace(e);
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#isDebugEnabled()
	 */
	public boolean isDebugEnabled() {
		return logger.isDebugEnabled();
	}

	/**
	 * @see org.esupportail.commons.services.logging.Logger#debugTime(java.lang.String, long)
	 */
	public void debugTime(final String str, final long start) {
		long duration = System.currentTimeMillis() - start;
		StringBuffer sb = new StringBuffer();
		sb.append("duration: ").append(duration).append(" -> ").append(str);
		debug(sb);
	}

	/**
	 * @see org.esupportail.commons.services.logging.Logger#debug(java.lang.StringBuffer)
	 */
	public void debug(final StringBuffer sb) {
		debug(sb.toString());
	}

	/**
	 * @see org.esupportail.commons.services.logging.Logger#debug(java.lang.String)
	 */
	public void debug(final String str) {
		if (str == null) {
			logger.debug(NULL);
		} else {
			String [] lines = str.split("\n");
			for (int i = 0; i < lines.length; i++) {
				logger.debug(lines[i]);
			}
		}
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#debug(java.lang.Exception)
	 */
	public void debug(final Exception e) {
		debug(ExceptionUtils.getPrintableStackTrace(e));
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#debug(java.lang.String, java.lang.Exception)
	 */
	public void debug(final String str, final Exception e) {
		debug(str);
		debug(e);
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#debug(java.lang.StringBuffer, java.lang.Exception)
	 */
	public void debug(final StringBuffer sb, final Exception e) {
		debug(sb.toString(), e);
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#debug(java.util.List)
	 */
	public void debug(final List<String> list) {
		for (String string : list) {
			debug(string);
		}
	}

	/**
	 * @see org.esupportail.commons.services.logging.Logger#debug(java.util.List, java.lang.Exception)
	 */
	public void debug(final List<String> list, final Exception e) {
		debug(list);
		debug(e);
	}

	/**
	 * @see org.esupportail.commons.services.logging.Logger#info(java.lang.String)
	 */
	public void info(final String str) {
		if (str == null) {
			logger.info(NULL);
		} else {
			String [] lines = str.split("\n");
			for (int i = 0; i < lines.length; i++) {
				logger.info(lines[i]);
			}
		}
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#info(java.lang.StringBuffer)
	 */
	public void info(final StringBuffer sb) {
		info(sb.toString());
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#info(java.lang.Exception)
	 */
	public void info(final Exception e) {
		info(ExceptionUtils.getPrintableStackTrace(e));
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#info(java.lang.String, java.lang.Exception)
	 */
	public void info(final String str, final Exception e) {
		info(str);
		info(e);
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#info(java.lang.StringBuffer, java.lang.Exception)
	 */
	public void info(final StringBuffer sb, final Exception e) {
		info(sb.toString(), e);
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#info(java.util.List)
	 */
	public void info(final List<String> list) {
		for (String string : list) {
			info(string);
		}
	}

	/**
	 * @see org.esupportail.commons.services.logging.Logger#info(java.util.List, java.lang.Exception)
	 */
	public void info(final List<String> list, final Exception e) {
		info(list);
		info(e);
	}

	/**
	 * @see org.esupportail.commons.services.logging.Logger#warn(java.lang.String)
	 */
	public void warn(final String str) {
		if (str == null) {
			logger.warn(NULL);
		} else {
			String [] lines = str.split("\n");
			for (int i = 0; i < lines.length; i++) {
				logger.warn(lines[i]);
			}
		}
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#warn(java.lang.StringBuffer)
	 */
	public void warn(final StringBuffer sb) {
		warn(sb.toString());
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#warn(java.lang.Exception)
	 */
	public void warn(final Exception e) {
		warn(ExceptionUtils.getPrintableStackTrace(e));
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#warn(java.lang.String, java.lang.Exception)
	 */
	public void warn(final String str, final Exception e) {
		warn(str);
		warn(e);
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#warn(java.lang.StringBuffer, java.lang.Exception)
	 */
	public void warn(final StringBuffer sb, final Exception e) {
		warn(sb.toString(), e);
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#warn(java.util.List)
	 */
	public void warn(final List<String> list) {
		for (String string : list) {
			warn(string);
		}
	}

	/**
	 * @see org.esupportail.commons.services.logging.Logger#warn(java.util.List, java.lang.Exception)
	 */
	public void warn(final List<String> list, final Exception e) {
		warn(list);
		warn(e);
	}

	/**
	 * @see org.esupportail.commons.services.logging.Logger#error(java.lang.String)
	 */
	public void error(final String str) {
		if (str == null) {
			logger.error(NULL);
		} else {
			String [] lines = str.split("\n");
			for (int i = 0; i < lines.length; i++) {
				logger.error(lines[i]);
			}
		}
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#error(java.lang.StringBuffer)
	 */
	public void error(final StringBuffer sb) {
		error(sb.toString());
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#error(java.lang.Exception)
	 */
	public void error(final Exception e) {
		error(ExceptionUtils.getPrintableStackTrace(e));
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#error(java.lang.String, java.lang.Exception)
	 */
	public void error(final String str, final Exception e) {
		error(str);
		error(e);
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#error(java.lang.StringBuffer, java.lang.Exception)
	 */
	public void error(final StringBuffer sb, final Exception e) {
		error(sb.toString(), e);
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#error(java.util.List)
	 */
	public void error(final List<String> list) {
		for (String string : list) {
			error(string);
		}
	}

	/**
	 * @see org.esupportail.commons.services.logging.Logger#error(java.util.List, java.lang.Exception)
	 */
	public void error(final List<String> list, final Exception e) {
		error(list);
		error(e);
	}

	/**
	 * @see org.esupportail.commons.services.logging.Logger#fatal(java.lang.String)
	 */
	public void fatal(final String str) {
		if (str == null) {
			logger.fatal(NULL);
		} else {
			String [] lines = str.split("\n");
			for (int i = 0; i < lines.length; i++) {
				logger.fatal(lines[i]);
			}
		}
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#fatal(java.lang.StringBuffer)
	 */
	public void fatal(final StringBuffer sb) {
		fatal(sb.toString());
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#fatal(java.lang.Exception)
	 */
	public void fatal(final Exception e) {
		fatal(ExceptionUtils.getPrintableStackTrace(e));
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#fatal(java.lang.String, java.lang.Exception)
	 */
	public void fatal(final String str, final Exception e) {
		fatal(str);
		fatal(e);
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#fatal(java.lang.StringBuffer, java.lang.Exception)
	 */
	public void fatal(final StringBuffer sb, final Exception e) {
		fatal(sb.toString(), e);
	}
	
	/**
	 * @see org.esupportail.commons.services.logging.Logger#fatal(java.util.List)
	 */
	public void fatal(final List<String> list) {
		for (String string : list) {
			fatal(string);
		}
	}

	/**
	 * @see org.esupportail.commons.services.logging.Logger#fatal(java.util.List, java.lang.Exception)
	 */
	public void fatal(final List<String> list, final Exception e) {
		fatal(list);
		fatal(e);
	}

}

