/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.database;

import java.util.List;


/**
 * An abstract implementation of the database manager store.
 */
public abstract class AbstractDatabaseManagerStore implements DatabaseManagerStore {

	/**
	 * Bean constructor.
	 */
	public AbstractDatabaseManagerStore() {
		super();
	}

	/**
	 * @see org.esupportail.commons.services.database.DatabaseManagerStore#open()
	 */
	public void open() {
		if (getDatabaseManagers() != null) {
			for (DatabaseManager databaseManager : getDatabaseManagers()) {
				databaseManager.openSession();
			}
		}
	}

	/**
	 * @see org.esupportail.commons.services.database.DatabaseManagerStore#begin()
	 */
	public void begin() {
		if (getDatabaseManagers() != null) {
			for (DatabaseManager databaseManager : getDatabaseManagers()) {
				databaseManager.beginTransaction();
			}
		}
	}

	/**
	 * @see org.esupportail.commons.services.database.DatabaseManagerStore#end(boolean)
	 */
	public void end(final boolean commit) {
		if (getDatabaseManagers() != null) {
			for (DatabaseManager databaseManager : getDatabaseManagers()) {
				databaseManager.endTransaction(commit);
			}
		}
	}

	/**
	 * @see org.esupportail.commons.services.database.DatabaseManagerStore#close()
	 */
	public void close() {
		if (getDatabaseManagers() != null) {
			for (int i = getDatabaseManagers().size() - 1; i >= 0; i--) {
				getDatabaseManagers().get(i).closeSession();
			}
		}
	}

	/**
	 * @see org.esupportail.commons.services.database.DatabaseManagerStore#test()
	 */
	public void test() {
		if (getDatabaseManagers() != null) {
			for (DatabaseManager databaseManager : getDatabaseManagers()) {
				databaseManager.test();
			}
		}
	}
	
	/**
	 * @see org.esupportail.commons.services.database.DatabaseManagerStore#create()
	 */
	public void create() {
		if (getDatabaseManagers() != null) {
			for (DatabaseManager databaseManager : getDatabaseManagers()) {
				if (databaseManager.isUpgradable()) {
					databaseManager.create();
				}
			}
		}
	}
	
	/**
	 * @see org.esupportail.commons.services.database.DatabaseManagerStore#update()
	 */
	public void update() {
		if (getDatabaseManagers() != null) {
			for (DatabaseManager databaseManager : getDatabaseManagers()) {
				if (databaseManager.isUpgradable()) {
					databaseManager.upgrade();
				}
			}
		}
	}

	protected abstract List<DatabaseManager> getDatabaseManagers();

}
