/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.web.tags;

import org.esupportail.commons.web.renderers.TextRenderer;

/**
 * ESUP-Portail implementation of the 'italic' tag.
 */
public class ItalicTag extends AbstractStyleWrapperTag {

	/**
	 * The italic style.
	 */
	private static final String ITALIC_STYLE = "font-style: italic; "; 
	
	/**
	 * Constructor.
	 */
	public ItalicTag() {
		super();
	}
	
	
	/**
	 * @see org.apache.myfaces.taglib.html.HtmlOutputFormatTag#getRendererType()
	 */
	@Override
	public String getRendererType() {
		return TextRenderer.RENDERER_TYPE;
	}
	
	
	/**
	 * @see org.esupportail.commons.web.tags.AbstractStyleWrapperTag#getStyle()
	 */
	@Override
	protected String getStyle() {
		return ITALIC_STYLE;
	}
}
