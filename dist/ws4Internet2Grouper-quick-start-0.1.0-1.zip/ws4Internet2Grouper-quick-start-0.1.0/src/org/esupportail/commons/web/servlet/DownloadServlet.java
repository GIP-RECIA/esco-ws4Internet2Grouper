/**
 * ESUP-Portail Blank Application - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-blank
 */
package org.esupportail.commons.web.servlet;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.esupportail.commons.exceptions.DownloadException;
import org.esupportail.commons.services.exceptionHandling.ExceptionUtils;
import org.esupportail.commons.utils.BeanUtils;
import org.esupportail.commons.utils.ContextUtils;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * The servlet to download files.
 */
public class DownloadServlet extends HttpServlet {

	/**
	 * The id for serialization.
	 */
	private static final long serialVersionUID = -7231367075834134378L;
	
	/**
	 * The atribute to retrieve the data from.
	 */
	private static final String DATA_ATTRIBUTE = "downloadData"; 

	/**
	 * The atribute to retrieve the content-type from.
	 */
	private static final String CONTENT_TYPE_ATTRIBUTE = "downloadContentType"; 

	/**
	 * The atribute to retrieve the filename from.
	 */
	private static final String FILENAME_ATTRIBUTE = "downloadFilename"; 

	/**
	 * Constructor.
	 */
	public DownloadServlet() {
		super();
	}

	/**
	 * @throws ServletException 
	 * @see javax.servlet.http.HttpServlet#service(javax.servlet.ServletRequest, javax.servlet.ServletResponse)
	 */
	@Override
	public void service(
			final ServletRequest servletRequest, 
			final ServletResponse servletResponse) 
	throws ServletException {
		HttpServletResponse response = (HttpServletResponse) servletResponse;
    	ServletRequestAttributes previousRequestAttributes = null;
        try {
        	previousRequestAttributes = ContextUtils.bindRequestAndContext(
        			(HttpServletRequest) servletRequest, getServletContext());
			BeanUtils.initBeanFactory(getServletContext());
			String contentType = (String) ContextUtils.getGlobalSessionAttribute(CONTENT_TYPE_ATTRIBUTE);
			if (contentType != null) {
				response.setContentType(contentType);
			}
			String filename = (String) ContextUtils.getGlobalSessionAttribute(FILENAME_ATTRIBUTE);
			if (filename != null) {
				response.setHeader("Content-disposition", "inline; filename=\"" + filename + "\"");
			}
			byte [] data = (byte []) ContextUtils.getGlobalSessionAttribute(DATA_ATTRIBUTE);
			if (data == null) {
				throw new DownloadException("data is null, can not download");
			}
			response.setContentLength(data.length);
			ServletOutputStream out = response.getOutputStream();
			out.write(data);
		} catch (Exception e) {
			Exception de = new DownloadException(e);
			ExceptionUtils.catchException(de);
        	ContextUtils.unbindRequest(previousRequestAttributes);
			throw new ServletException(de);
		}
	}

}
