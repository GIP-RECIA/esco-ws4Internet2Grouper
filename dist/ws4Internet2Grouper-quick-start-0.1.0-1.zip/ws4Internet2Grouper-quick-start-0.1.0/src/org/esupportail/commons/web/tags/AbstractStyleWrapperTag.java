/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.web.tags;

import javax.faces.component.UIComponent;

import org.apache.myfaces.shared_impl.renderkit.html.HTML;

/**
 * An abstract class for tags that set a default style.
 */
public abstract class AbstractStyleWrapperTag extends AbstractWrapperTag {

	/**
	 * Constructor.
	 */
	public AbstractStyleWrapperTag() {
		super();
	}
	
	/**
	 * @return the style to apply.
	 */
	protected abstract String getStyle();

	/**
	 * @see org.apache.myfaces.shared_impl.taglib.html.HtmlOutputFormatTagBase#setProperties(
	 * javax.faces.component.UIComponent)
	 */
	@SuppressWarnings("unchecked")
	@Override
	protected void setProperties(final UIComponent component) {
		String style = getStyle();
		if (style != null) {
			setStringProperty(component, HTML.STYLE_ATTR, getStyle());
		}
		super.setProperties(component);
	}

}
