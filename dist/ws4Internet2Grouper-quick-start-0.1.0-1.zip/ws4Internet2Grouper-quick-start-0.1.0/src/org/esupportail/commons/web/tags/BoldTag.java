/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.web.tags;

import org.esupportail.commons.web.renderers.TextRenderer;

/**
 * ESUP-Portail implementation of the 'bold' tag.
 */
public class BoldTag extends AbstractStyleWrapperTag {

	/**
	 * The bold style.
	 */
	private static final String BOLD_STYLE = "{font-weight: bold;}"; 
	
	/**
	 * Constructor.
	 */
	public BoldTag() {
		super();
	}
	
	/**
	 * @see org.apache.myfaces.taglib.html.HtmlOutputFormatTag#getRendererType()
	 */
	@Override
	public String getRendererType() {
		return TextRenderer.RENDERER_TYPE;
	}
	
	/**
	 * @see org.esupportail.commons.web.tags.AbstractStyleWrapperTag#getStyle()
	 */
	@Override
	protected String getStyle() {
		return BOLD_STYLE;
	}
}
