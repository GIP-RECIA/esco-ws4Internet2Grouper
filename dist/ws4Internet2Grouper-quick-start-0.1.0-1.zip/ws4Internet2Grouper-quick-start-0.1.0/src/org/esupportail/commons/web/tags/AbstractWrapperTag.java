/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.web.tags;

import javax.faces.component.UIComponent;

import org.apache.myfaces.taglib.html.HtmlOutputFormatTag;

/**
 * An abstract class for tags that wrap into a HTML tag.
 */
public abstract class AbstractWrapperTag extends HtmlOutputFormatTag {

	/**
	 * Constructor.
	 */
	public AbstractWrapperTag() {
		super();
	}
	
	/**
	 * @see org.apache.myfaces.shared_impl.taglib.html.HtmlOutputFormatTagBase#setProperties(
	 * javax.faces.component.UIComponent)
	 */
	@SuppressWarnings("unchecked")
	@Override
	protected void setProperties(final UIComponent component) {
		super.setProperties(component);
	}

}
