/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.web.beans; 

import java.util.List;

/** 
 * The interface of paginators, used to display displaying results 
 * from a large result set over a number of pages without retrieving 
 * all the items from the database. 
 * 
 * Adapted from http://blog.hibernate.org/cgi-bin/blosxom.cgi/2004/08/14#fn.html and
 * http://blog.hibernate.org/cgi-bin/pollxn.cgi?storypath=/Gavin%20King/pagination.html
 * @param <E> the class of the results
 */ 
public interface Paginator<E> { 
	
	/**
	 * @return the page size.
	 */
	int getPageSize();

	/**
	 * @return the current page number.
	 */
	int getCurrentPage();
	
	/**
	 * Refresh the data.
	 */
	void reloadData();
	
	/**
	 * Go to the next page.
	 */
	void gotoNextPage();

	/**
	 * Go to the previous page.
	 */
	void gotoPreviousPage();

	/**
	 * Go to the first page.
	 */
	void gotoFirstPage();

	/**
	 * Go to the last page.
	 */
	void gotoLastPage();

	/**
	 * @return true if the page is the first one.
	 */
	boolean isFirstPage();
	
	/**
	 * @return true if the page is the last one.
	 */
	boolean isLastPage();
	
	/**
	 * @return the number of the previous page.
	 */
	int getPreviousPage();

	/**
	 * @return the number of the next page.
	 */
	int getNextPage();

	/**
	 * @return the number of the first page (always 0).
	 */
	int getFirstPageNumber();

	/**
	 * @return the number of the last page.
	 */
	int getLastPageNumber();

	/**
	 * @return the number of the first result.
	 */
	int getFirstVisibleNumber();
	
	/**
	 * @return the number of the last result.
	 */
	int getLastVisibleNumber();
	
	/**
	 * @return the list of the results.
	 */
	List<E> getVisibleItems();
	
	/**
	 * @return the number of visible items.
	 */
	int getVisibleItemsCount();
	
	/**
	 * @return the total number of items.
	 */
	int getTotalItemsCount();
	
	/**
	 * @return The numbers of the near pages.
	 */
	List<Integer> getNearPages();
	
} 

