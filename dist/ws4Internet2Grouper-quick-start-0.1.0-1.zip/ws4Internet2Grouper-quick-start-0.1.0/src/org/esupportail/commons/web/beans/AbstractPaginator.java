/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.web.beans; 

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.faces.model.SelectItem;



/** 
 * An abstract paginator, independant from the underlying database implementation.
 * @param <E> the class of the visibleItems
 */ 
public abstract class AbstractPaginator<E> implements Paginator<E> {
	
	/**
     * The default values for pageSizeItems.
     */
    protected static final Integer [] DEFAULT_PAGE_SIZE_ITEM_VALUES = {5, 10, 15, 20};
    
	/**
	 * The maximum number of near pages to print.
	 */
	private static final int MAX_NEAR_PAGES = 12;

	/**
	 * The current page number, normally set by constructor.
	 */
	private int currentPage;
	
	/**
	 * The page size, i.e. the number of visibleItems to display per page, 
	 * normally set by the constructor.
	 */
	private int pageSize;
	
	/**
	 * The visible items, normally set by the constructor.
	 */
	private List<E> visibleItems;
	
	/**
	 * The total number of items, normally set by the constructor.
	 */
	private int totalItemsCount;
	
    /**
     * The page size items.
     */
    private List<SelectItem> pageSizeItems;
    
	/**
	 * Constructor.
	 * @param pageSizeValues 
	 * @param pageSize 
	 */
	protected AbstractPaginator(
			final List<Integer> pageSizeValues,
			final int pageSize) {
		super();
		List<Integer> thePageSizeValues;
		if (pageSizeValues == null) {
			thePageSizeValues = Arrays.asList(getDefaultPageSizeItemValues());
		} else {
			thePageSizeValues = pageSizeValues;
		}
		pageSizeItems = new ArrayList<SelectItem>();
		for (Integer pageSizeValue : thePageSizeValues) {
			pageSizeItems.add(new SelectItem(pageSizeValue));
		}
		if (this.pageSize == 0) {
			this.pageSize = thePageSizeValues.get(0);
		} else {
			this.pageSize = pageSize;
		}
	}
	
	/**
	 * Load the data (should be called right after the constructor).
	 * Usage: paginator = new PaginatorImpl(...).loadData().
	 * @return the object itself
	 */
	public Paginator<E> loadData() {
		reloadData();
		return this;
	}

	/**
	 * @return the default page size values.
	 */
	protected Integer [] getDefaultPageSizeItemValues() {
		return DEFAULT_PAGE_SIZE_ITEM_VALUES;
	}

	/**
	 * @see org.esupportail.commons.web.beans.Paginator#gotoPreviousPage()
	 */
	private void gotoPage(final int page) {
		currentPage = page;
		reloadData();
	}

    /**
	 * @see org.esupportail.commons.web.beans.Paginator#gotoFirstPage()
	 */
	public void gotoFirstPage() {
		gotoPage(0);
	}

	/**
	 * @see org.esupportail.commons.web.beans.Paginator#gotoLastPage()
	 */
	public void gotoLastPage() {
		gotoPage(getLastPageNumber());
	}

	/**
	 * @see org.esupportail.commons.web.beans.Paginator#gotoNextPage()
	 */
	public void gotoNextPage() {
		gotoPage(currentPage + 1);
	}

	/**
	 * @see org.esupportail.commons.web.beans.Paginator#gotoPreviousPage()
	 */
	public void gotoPreviousPage() {
		gotoPage(currentPage - 1);
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return getClass().getSimpleName() + "#" + hashCode() + "[pageSize=[" + getPageSize() 
		+ "], currentPage=" + getCurrentPage() + "]";
	}
	
	/**
	 * @return the pageSize
	 */
	public int getPageSize() {
		return pageSize;
	}

	/**
	 * @see org.esupportail.commons.web.beans.Paginator#getCurrentPage()
	 */
	public int getCurrentPage() {
		return currentPage;
	}

	/**
	 * @see org.esupportail.commons.web.beans.Paginator#isFirstPage()
	 */
	public boolean isFirstPage() {
		return currentPage <= 0; 
	}

	/**
	 * @see org.esupportail.commons.web.beans.Paginator#isLastPage()
	 */
	public boolean isLastPage() {
		return currentPage >= getLastPageNumber(); 
	} 

	/**
	 * @see org.esupportail.commons.web.beans.Paginator#getPreviousPage()
	 */
	public final int getPreviousPage() {
		return currentPage - 1;
	}

	/**
	 * @see org.esupportail.commons.web.beans.Paginator#getNextPage()
	 */
	public final int getNextPage() {
		return currentPage + 1;
	}

	/**
	 * @see org.esupportail.commons.web.beans.Paginator#getFirstPageNumber()
	 */
	public final int getFirstPageNumber() {
		return 0; 
	}

	/**
	 * @see org.esupportail.commons.web.beans.Paginator#getLastPageNumber()
	 */
	public int getLastPageNumber() {
		return (getTotalItemsCount() - 1) / pageSize; 
	}

	/**
	 * @see org.esupportail.commons.web.beans.Paginator#getFirstVisibleNumber()
	 */
	public int getFirstVisibleNumber() {
		return currentPage * pageSize; 
	}

	/**
	 * @see org.esupportail.commons.web.beans.Paginator#getLastVisibleNumber()
	 */
	public int getLastVisibleNumber() {
		return Math.min(getFirstVisibleNumber() + pageSize - 1, getTotalItemsCount() - 1);
	}

	/**
	 * @param currentPage the currentPage to set
	 */
	public void setCurrentPage(final int currentPage) {
		this.currentPage = currentPage;
	}

	/**
	 * @param visibleItems the visibleItems to set
	 */
	protected void setVisibleItems(final List<E> visibleItems) {
		this.visibleItems = visibleItems;
	}

	/**
	 * @see org.esupportail.commons.web.beans.Paginator#getVisibleItems()
	 */
	public List<E> getVisibleItems() {
		return visibleItems;
	}

	/**
	 * @see org.esupportail.commons.web.beans.Paginator#getNearPages()
	 */
	public List<Integer> getNearPages() {
		List<Integer> result = new ArrayList<Integer>();
		int first = Math.max(getFirstPageNumber(), currentPage - MAX_NEAR_PAGES / 2);
		int last = Math.min(getLastPageNumber(), currentPage + MAX_NEAR_PAGES / 2);
		for (int i = first; i <= last; i++) {
			result.add(i);
		}
		return result;
	}

	/**
	 * @see org.esupportail.commons.web.beans.Paginator#getVisibleItemsCount()
	 */
	public int getVisibleItemsCount() {
		return visibleItems.size();
	}

	/**
	 * @see org.esupportail.commons.web.beans.Paginator#getTotalItemsCount()
	 */
	public int getTotalItemsCount() {
		return totalItemsCount;
	}

	/**
	 * @param totalItemsCount the totalItemsCount to set
	 */
	protected void setTotalItemsCount(final int totalItemsCount) {
		this.totalItemsCount = totalItemsCount;
	}

	/**
	 * @return the pageSizeItems
	 */
	public List<SelectItem> getPageSizeItems() {
		return pageSizeItems;
	}

	/**
	 * @param pageSize the pageSize to set
	 */
	public void setPageSize(final int pageSize) {
		if (this.pageSize != pageSize) {
			this.pageSize = pageSize;
			currentPage = 0;
			reloadData();
		}
	}

} 

