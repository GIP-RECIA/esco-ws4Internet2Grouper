/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.web.beans; 

import java.util.ArrayList;
import java.util.List;

/** 
 * A paginator built on existing lists.
 * @param <E> the class of the visibleItems
 */ 
public abstract class ListPaginator<E> extends AbstractPaginator<E> {

	/**
	 * Bean constructor.
	 * @param pageSizeValues 
	 * @param pageSize
	 */
	public ListPaginator(
			final List<Integer> pageSizeValues,
			final int pageSize) {
		super(pageSizeValues, pageSize);
	}
	
	/**
	 * @see org.esupportail.commons.web.beans.Paginator#reloadData()
	 */
	public void reloadData() {
		List<E> list = getData();
		if (list == null || list.isEmpty()) {
			setCurrentPage(0);
			setVisibleItems(new ArrayList<E>()); 
			return;
		}
		setTotalItemsCount(list.size());
		int begin = getPageSize() * getCurrentPage();
		int end = Math.min(getPageSize() * (getCurrentPage() + 1), getTotalItemsCount()); 
		if (begin > end) {
			setCurrentPage(0);
			end = Math.min(getPageSize() * (getCurrentPage() + 1), getTotalItemsCount()); 
		}
		setVisibleItems(list.subList(begin, end));
		if (getVisibleItemsCount() == 0 && getTotalItemsCount() != 0) {
			setCurrentPage(getLastPageNumber());
			begin = getPageSize() * getCurrentPage();
			end = Math.min(getPageSize() * (getCurrentPage() + 1), getTotalItemsCount()); 
			setVisibleItems(list.subList(begin, end));
		}
	}

	/**
	 * @return the data to set.
	 */
	protected abstract List<E> getData();

} 

