/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.web.tags;

import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.faces.webapp.UIComponentTag;

import org.esupportail.commons.services.logging.Logger;
import org.esupportail.commons.services.logging.LoggerImpl;
import org.springframework.util.Assert;

/**
 * Utility class for tags.
 */
public class TagUtils {
	
	/**
	 * A logger.
	 */
	private static final Logger LOG = new LoggerImpl(TagUtils.class);

	/**
	 * Bean constructor.
	 */
	private TagUtils() {
		throw new UnsupportedOperationException();
	}
	
	/**
	 * This method can be used to 'decode' the attributes of tags 
	 * ('#{xxx} are replaced by their real value).
	 * @param attrValue
	 * @return the 'real' value.
	 */
	public static Object getAttributeValue(
			final String attrValue) {
		if (attrValue == null) {
			return null;
		}
		if (!UIComponentTag.isValueReference(attrValue)) {
			return attrValue;
		}
        FacesContext facesContext = FacesContext.getCurrentInstance();
        Assert.notNull(facesContext, "facesContext should not be null");
        ValueBinding vb = facesContext.getApplication().createValueBinding(attrValue);
        return vb.getValue(facesContext);
	}

	/**
	 * @param attrName
	 * @param attrValue
	 * @return the 'real' boolean value of a tag attribute.
	 */
	public static Boolean getBooleanAttributeValue(
			final String attrName,
			final String attrValue) {
		Object value = getAttributeValue(attrValue);
		if (value == null) {
			return null;
		}
		if (value instanceof Boolean) {
			return (Boolean) value;
		}
		if (value instanceof String) {
			return Boolean.valueOf((String) value);
		}
		throw new TagException("attribute '" + attrName + "' is not a boolean ([" + value + "])");
	}

	/**
	 * @param attrName
	 * @param attrValue
	 * @return the 'real' string value of a tag attribute.
	 */
	public static String getStringAttributeValue(
			final String attrName,
			final String attrValue) {
		Object value = getAttributeValue(attrValue);
		if (value == null) {
			return null;
		}
		if (value instanceof String) {
			return (String) value;
		}
		LOG.error("attribute '" + attrName + "' is not a string");
		return value.toString();
	}

}
