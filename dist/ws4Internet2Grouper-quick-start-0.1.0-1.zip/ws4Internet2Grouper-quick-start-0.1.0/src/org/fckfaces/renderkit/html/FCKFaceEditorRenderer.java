package org.fckfaces.renderkit.html;

import org.apache.myfaces.renderkit.html.HtmlTextareaRenderer;

/**
 * 
 */
public class FCKFaceEditorRenderer extends HtmlTextareaRenderer {

	/**
	 * Bean constructor.
	 */
	public FCKFaceEditorRenderer() {
		super();
	}

}
