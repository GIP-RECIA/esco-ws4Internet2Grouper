package org.fckfaces.util;

import javax.faces.context.FacesContext;

/**
 * 
 */
public class Util {
	
	/**
	 * 
	 */
	public static final String FCK_FACES_RESOURCE_PREFIX = "/media";
//	public static final String FCK_FACES_RESOURCE_PREFIX = "/fckfaces";
	
	/**
	 * Constructor.
	 */
	private Util() {
		throw new UnsupportedOperationException();
	}

	/**
	 * @param path
	 * @return x
	 */
	public static final String internalPath(final String path) {
		return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath() 
		+ FCK_FACES_RESOURCE_PREFIX + path;
	}
	
	/**
	 * @param path
	 * @return x
	 */
	public static final String externalPath(final String path) {
		return FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath() + path;
	}
}
