﻿/*
 * FCKeditor - The text editor for internet
 * Copyright (C) 2003-2006 Frederico Caldeira Knabben
 * 
 * Licensed under the terms of the GNU Lesser General Public License:
 * 		http://www.opensource.org/licenses/lgpl-license.php
 * 
 * For further information visit:
 * 		http://www.fckeditor.net/
 * 
 * "Support Open Source software. What about a donation today?"
 * 
 * File Name: it.js
 * 	Italian language file for the sample plugin.
 * 
 * File Authors:
 * 		Frederico Caldeira Knabben (fredck@fckeditor.net)
 */

FCKLang['DlgMyReplaceTitle']		= 'Plugin - Sostituisci' ;
FCKLang['DlgMyReplaceFindLbl']		= 'Trova:' ;
FCKLang['DlgMyReplaceReplaceLbl']	= 'Sostituisci con:' ;
FCKLang['DlgMyReplaceCaseChk']		= 'Maiuscole/minuscole' ;
FCKLang['DlgMyReplaceReplaceBtn']	= 'Sostituisci' ;
FCKLang['DlgMyReplaceReplAllBtn']	= 'Sostituisci tutto' ;
FCKLang['DlgMyReplaceWordChk']		= 'Parola intera' ;

FCKLang['DlgMyFindTitle']			= 'Plugin - Cerca' ;
FCKLang['DlgMyFindFindBtn']			= 'Cerca' ;