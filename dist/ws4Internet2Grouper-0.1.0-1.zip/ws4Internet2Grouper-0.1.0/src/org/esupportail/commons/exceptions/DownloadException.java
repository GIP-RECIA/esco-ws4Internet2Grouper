/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.exceptions; 

/**
 * A class for download exceptions.
 */
public class DownloadException extends EsupException {

	/**
	 * The id for serialization.
	 */
	private static final long serialVersionUID = 7165963791514558078L;

	/**
	 * @param message
	 */
	public DownloadException(final String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public DownloadException(final Exception cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public DownloadException(final String message, final Exception cause) {
		super(message, cause);
	}

}
