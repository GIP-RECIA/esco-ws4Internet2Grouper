/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.utils.strings; 

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.springframework.web.util.HtmlUtils;

/**
 * A class to convert HTML to text using Swing.
 */
public final class StringUtils {   
	
	/**
	 * Private constructor.
	 */
	private StringUtils() {
		throw new UnsupportedOperationException();
	}

	/**
	 * Parse HTML and return text.
	 * @param htmlString an HTML string.
	 * @return a String.
	 * @throws IOException
	 */
	public static String htmlToText(final String htmlString) throws IOException {
		return HtmlToTextParserCallBack.convert(htmlString);
	}

	/**
	 * @param input
	 * @return The input string where special HTML characters have been replaced.
	 */
	public static String escapeHtml(final String input) {
		return HtmlUtils.htmlEscape(input);
	}

	/**
	 * @return the line separator.
	 */
	public static String getLineSeparator() {
		String ls = System.getProperty("line.separator");
		if (ls == null) {
			ls = "\n";
		}
		return ls;
	}
	
	/**
	 * @param input 
	 * @return null if the input string is empty. 
	 */
	public static String nullIfEmpty(final String input) {
		if (!org.springframework.util.StringUtils.hasText(input)) {
			return null;
		}
		return input;
	}
	
	/**
	 * Encode a URL.
	 * @param input 
	 * @return the encoded string.
	 */
	public static String utf8UrlEncode(final String input) {
		try {
			return URLEncoder.encode(input, "utf-8");
		} catch (UnsupportedEncodingException e) {
			return e.getMessage();
		}
	}

}
