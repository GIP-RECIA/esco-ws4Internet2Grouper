/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.utils; 

import java.util.Enumeration;
import java.util.Set;
import java.util.TreeSet;

import javax.servlet.ServletRequest;
import javax.servlet.ServletRequestWrapper;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Utilities to debug.
 * TODO PA: is this class used?
 */
public class DebugUtils {

	/**
	 * No instanciation.
	 */
	private DebugUtils() {
		throw new UnsupportedOperationException();
	}

	/**
	 * @param level
	 * @return a prefix to indent things.
	 */
	private static String indentPrefix(final int level) {
		String result = "*";
		for (int i = 0; i < level; i++) {
			result += "    ";
		}
		return result + "| ";
	}

	/**
	 * print an object with an indentation level.
	 * @param title
	 * @param o
	 * @param level
	 */
	@SuppressWarnings("unchecked")
	private static void print(final String title, final Object o, final int level) {
		System.err.println(indentPrefix(level - 1) + title);
		final String prefix = indentPrefix(level);
		if (o == null) {
			System.err.println(prefix + "null");
		} else {
			System.err.println(prefix + o.toString());
			System.err.println(prefix + "class = [" + o.getClass().getName() + "]");
			if (o instanceof ServletRequest) {
				final ServletRequest servletRequest = (ServletRequest) o;
				System.err.println(prefix + "Scheme: " + servletRequest.getScheme());
				final Enumeration<String> attributeNames = servletRequest.getAttributeNames();
				if (attributeNames.hasMoreElements()) {
					System.err.println(prefix + "Attributes:");
					Set<String> strings = new TreeSet<String>();
					while (attributeNames.hasMoreElements()) {
						String name = attributeNames.nextElement();
						Object value = servletRequest.getAttribute(name);
						strings.add("- '" + name + "' = [" + value + "]");
					}
					for (final String string : strings) {
						System.err.println(prefix + string);
					}
				} else {
					System.err.println(prefix + "No attribute.");
				}
				final Enumeration<String> parameterNames = servletRequest.getParameterNames();
				if (parameterNames.hasMoreElements()) {
					System.err.println(prefix + "Parameters:");
					Set<String> strings = new TreeSet<String>();
					while (parameterNames.hasMoreElements()) {
						String name = parameterNames.nextElement();
						String [] values = servletRequest.getParameterValues(name);
						for (int i = 0; i < values.length; i++) {
							final String value = values[i];
							strings.add("- '" + name + "' = [" + value + "]");
						}
					}
					for (final String string : strings) {
						System.err.println(prefix + string);
					}
				} else {
					System.err.println(prefix + "No parameter.");
				}
				if (servletRequest instanceof HttpServletRequest) {
					HttpServletRequest httpServletRequest = 
						(HttpServletRequest) servletRequest;
					System.err.println(prefix + "Query string: [" 
							+ httpServletRequest.getQueryString() + "]");
					HttpSession httpSession = httpServletRequest.getSession(false);
					System.err.println(prefix + "Session: [" 
							+ httpSession + "]");
//					if (httpSession != null) {
//					}
				}
			}
			if (o instanceof ServletRequestWrapper) {
				ServletRequestWrapper requestWrapper = (ServletRequestWrapper) o;
				print("getRequest()", requestWrapper.getRequest(), level + 1);
			}
		}
	}

	/**
	 * Debug any object.
	 * @param title
	 * @param o
	 */
	public static void print(final String title, final Object o) {
		System.err.println("*******************************************************************");
		print(title, o, 1);
		System.err.println("*******************************************************************");
	}

}
