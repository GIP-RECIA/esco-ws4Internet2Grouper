/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.dao;

import java.util.List;

import org.esupportail.commons.services.logging.Logger;
import org.esupportail.commons.services.logging.LoggerImpl;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.dao.support.DataAccessUtils;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * An abstract DAO implementation.
 */
public abstract class AbstractHibernateDaoService extends HibernateDaoSupport {

	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String SELECT_KEYWORD = " SELECT ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String COUNT_KEYWORD = " COUNT ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String AS_KEYWORD = " AS ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String DISTINCT_KEYWORD = " DISTINCT ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String STAR_KEYWORD = " * ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String OPEN_PAREN_KEYWORD = " ( ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String CLOSE_PAREN_KEYWORD = " ) ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String COMMA_KEYWORD = " , ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String COUNT_ALL_PHRASE = 
		COUNT_KEYWORD + OPEN_PAREN_KEYWORD + STAR_KEYWORD + CLOSE_PAREN_KEYWORD;
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String FROM_KEYWORD = " FROM ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String ORDER_BY_KEYWORD = " ORDER BY ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String DESC_KEYWORD = " DESC ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String ASC_KEYWORD = " ASC ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String WHERE_KEYWORD = " WHERE ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String EXISTS_KEYWORD = " EXISTS ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String DOT_KEYWORD = ".";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String EQUALS_KEYWORD = " = ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String LIKE_KEYWORD = " LIKE ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String TRUE_KEYWORD = " true ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String FALSE_KEYWORD = " false ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String QUOTE_KEYWORD = "'";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String AND_KEYWORD = " AND ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String OR_KEYWORD = " OR ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String NOT_KEYWORD = " NOT ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String IN_KEYWORD = " IN ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String IS_NULL_PHRASE = " IS NULL ";
	
	/** @deprecated Use {@link HqlUtils} */
	@Deprecated
	public static final String IS_NOT_NULL_PHRASE = " IS NOT NULL ";
	
	/**
	* A logger.
	*/
	private Logger logger = new LoggerImpl(getClass()); 

	/**
	 * Bean constructor.
	 */
	public AbstractHibernateDaoService() {
		super();
	}

	/**
	 * @param hqlQuery 
	 * @return a Query.
	 */
	public Query getQuery(
			final String hqlQuery) {
		return (Query) getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(final Session session) throws HibernateException {
						return session.createQuery(hqlQuery);
					}
				}
		);
	}
	
	/**
	 * Count entries of the database.
	 * @param countQuery the query
	 * @return an integer.
	 */
	protected int getQueryIntResult(final String countQuery) {
		return DataAccessUtils.intResult(getHibernateTemplate().find(countQuery));
	}
	
	//////////////////////////////////////////////////////////////
	// misc
	//////////////////////////////////////////////////////////////

	/**
	 * Add an object into the database.
	 * @param object 
	 */
	protected void addObject(final Object object) {
		if (logger.isDebugEnabled()) {
			logger.debug("adding " + object + "...");
		}
		getHibernateTemplate().save(object);
		if (logger.isDebugEnabled()) {
			logger.debug("done.");
		}
	}

	/**
	 * Update an object in the database.
	 * @param object 
	 */
	protected void updateObject(final Object object) {
		if (logger.isDebugEnabled()) {
			logger.debug("merging " + object + "...");
		}
		Object merged = getHibernateTemplate().merge(object);
		if (logger.isDebugEnabled()) {
			logger.debug("done, updating " + merged + "...");
		}
		getHibernateTemplate().update(merged);
		if (logger.isDebugEnabled()) {
			logger.debug("done.");
		}
	}

	/**
	 * Delete an object from the database.
	 * @param object 
	 */
	protected void deleteObject(final Object object) {
		if (logger.isDebugEnabled()) {
			logger.debug("merging " + object + "...");
		}
		Object merged = getHibernateTemplate().merge(object);
		if (logger.isDebugEnabled()) {
			logger.debug("done, deleting " + merged + "...");
		}
		getHibernateTemplate().delete(merged);
		if (logger.isDebugEnabled()) {
			logger.debug("done.");
		}
	}

	/**
	 * Delete a list of objects from the database.
	 * @param objects 
	 */
	@SuppressWarnings("unchecked")
	protected void deleteObjects(final List objects) {
		getHibernateTemplate().deleteAll(objects);
	}

}
