/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.dao; 

import java.util.List;

/** 
 * A Hibernate paginator.
 * @param <E> the class of the results
 */ 
public class FixedQueryHibernatePaginator<E> extends AbstractHibernatePaginator<E> {
	
	/**
	 * The fixed query string.
	 */
	private String queryStr;
	
	/** 
	 * Constructor.
	 * @param daoService 
	 * @param queryStr
	 * @param pageSizeValues 
	 * @param pageSize the number of results to display on the page 
	 */ 
	@SuppressWarnings("unchecked")
	public FixedQueryHibernatePaginator(
			final AbstractHibernateDaoService daoService,
			final String queryStr,
			final List<Integer> pageSizeValues,
			final int pageSize) { 
		super(daoService, pageSizeValues, pageSize);
		this.queryStr = queryStr;
	} 
	
	/** 
	 * Constructor.
	 * @param daoService 
	 * @param queryStr
	 * @param pageSizeValues 
	 */ 
	@SuppressWarnings("unchecked")
	public FixedQueryHibernatePaginator(
			final AbstractHibernateDaoService daoService,
			final String queryStr,
			final List<Integer> pageSizeValues) { 
		this(daoService, queryStr, pageSizeValues, 0);
	} 
	
	/** 
	 * Constructor.
	 * @param daoService 
	 * @param queryStr
	 * @param pageSize the number of results to display on the page 
	 */ 
	@SuppressWarnings("unchecked")
	public FixedQueryHibernatePaginator(
			final AbstractHibernateDaoService daoService,
			final String queryStr,
			final int pageSize) { 
		this(daoService, queryStr, null, pageSize);
	} 
	
	/** 
	 * Constructor.
	 * @param daoService 
	 * @param queryStr
	 */ 
	@SuppressWarnings("unchecked")
	public FixedQueryHibernatePaginator(
			final AbstractHibernateDaoService daoService,
			final String queryStr) { 
		this(daoService, queryStr, null, 0);
	} 
	
	/**
	 * @see org.esupportail.commons.dao.AbstractHibernatePaginator#getQueryString()
	 */
	@Override
	protected String getQueryString() {
		return queryStr;
	}

} 

