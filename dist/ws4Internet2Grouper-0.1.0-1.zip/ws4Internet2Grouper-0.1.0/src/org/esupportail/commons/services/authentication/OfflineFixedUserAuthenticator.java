/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.authentication;

import org.esupportail.commons.utils.Assert;
import org.esupportail.commons.utils.ContextUtils;
import org.springframework.beans.factory.InitializingBean;

/** 
 * This authenticator is to be used when working offline, it always returns the same user.
 */
public class OfflineFixedUserAuthenticator implements AuthenticationService, InitializingBean {
	
	/**
	 * The id of the fixed user.
	 */
	private String userId;

	/**
	 * Bean constructor.
	 */
	public OfflineFixedUserAuthenticator() {
		super();
	}

	/**
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	public void afterPropertiesSet() throws Exception {
		Assert.hasText(this.userId, 
				"property userId of class " + this.getClass().getName() 
				+ " can not be null");
	}

	/**
	 * @see org.esupportail.commons.services.authentication.AuthenticationService#getCurrentUserId()
	 */
	public String getCurrentUserId() {
		if (!ContextUtils.isWeb()) {
			return null;
		}
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(final String userId) {
		this.userId = userId;
	}

}
