/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.urlGeneration; 

import java.util.Map;

/**
 * The interface of URL generators.
 */
public interface UrlGenerator {

	/**
	 * @param params 
	 * @return a link to the application with parameters.
	 */
	String url(final Map<String, String> params);

	/**
	 * @return a link to the application with no parameter.
	 */
	String url();

	/**
	 * @param params 
	 * @return a link to the application with parameters via the CAS server.
	 */
	String urlViaCas(final Map<String, String> params);

	/**
	 * @return a link to the application with no parameter via the CAS server.
	 */
	String urlViaCas();

}
