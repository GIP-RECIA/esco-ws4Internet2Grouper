/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.database.hibernate;


/**
 * An abstract class for non updatable database managers.
 */
public class BasicHibernateDatabaseManagerImpl 
extends AbstractHibernateDatabaseManagerImpl {

	/**
	 * true for a transactionnal manager.
	 */
	private boolean transactionnal;
	
	/**
	 * Bean constructor.
	 */
	public BasicHibernateDatabaseManagerImpl() {
		super();
	}

	/**
	 * @see org.esupportail.commons.services.database.DatabaseManager#isTransactionnal()
	 */
	public boolean isTransactionnal() {
		return transactionnal;
	}

	/**
	 * @param transactionnal the transactionnal to set
	 */
	public void setTransactionnal(final boolean transactionnal) {
		this.transactionnal = transactionnal;
	}

}
