/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.application; 


/**
 * the interface of the beans for versionning management.
 */
public interface VersionningService {

	/**
	 * Initialize the database.
	 */
	void initDatabase();
	
	/**
	 * check the database version, silently upgrade if possible.
	 * @param throwException 
	 * @param printLatestVersion 
	 * @throws VersionException 
	 */
	void checkVersion(
			final boolean throwException,
			final boolean printLatestVersion) throws VersionException;
	
	/**
	 * Upgrade the database.
	 */
	void upgradeDatabase();
	
}
