/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.authentication; 

import org.esupportail.commons.utils.BeanUtils;

/**
 * A class that provides static utilities for applications.
 */
public final class AuthenticationUtils {
	
	/**
	 * The name of the application service bean.
	 */
	private static final String AUTHENTICATION_SERVICE_BEAN = "authenticationService";

	/**
	 * Private constructor.
	 */
	private AuthenticationUtils() {
		throw new UnsupportedOperationException();
	}

	/**
	 * @return an authentication service.
	 */
	public static AuthenticationService createAuthenticationService() {
		return (AuthenticationService) BeanUtils.getBean(AUTHENTICATION_SERVICE_BEAN);
	}
	
}

