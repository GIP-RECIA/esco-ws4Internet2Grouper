/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.application;

import org.esupportail.commons.exceptions.ConfigException;

/**
 * A versionning service that does nothing.
 */
public class VoidVersionningServiceImpl implements VersionningService {

	/**
	 * Bean constructor.
	 */
	public VoidVersionningServiceImpl() {
		super();
	}
	
	/**
	 * @see org.esupportail.commons.services.application.VersionningService#checkVersion(boolean, boolean)
	 */
	public void checkVersion(
			final boolean throwException, 
			final boolean printLatestVersion)
	throws ConfigException {
		// nothing to do here
	}

	/**
	 * @see org.esupportail.commons.services.application.VersionningService#initDatabase()
	 */
	public void initDatabase() {
		// nothing to do here
	}

	/**
	 * @see org.esupportail.commons.services.application.VersionningService#upgradeDatabase()
	 */
	public void upgradeDatabase() {
		// nothing to do here
	}

}
