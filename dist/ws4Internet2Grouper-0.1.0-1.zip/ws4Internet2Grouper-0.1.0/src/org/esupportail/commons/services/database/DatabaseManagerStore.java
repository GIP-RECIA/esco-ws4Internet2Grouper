/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.database;


/**
 * The interface of the database manager stores.
 */
public interface DatabaseManagerStore {
	
	/**
	 * Open the database connections.
	 */
	void open();

	/**
	 * Begin a transaction for all the database managers.
	 */
	void begin();

	/**
	 * End the current transaction.
	 * @param commit true to commit the current transaction, false to rollback
	 */
	void end(final boolean commit);

	/**
	 * Close the database connections, rollback the current transaction if any.
	 */
	void close();

	/**
	 * Test the database connections.
	 */
	void test();
	
	/**
	 * Create the database structures.
	 */
	void create();
	
	/**
	 * Update the database structures.
	 */
	void update();

}
