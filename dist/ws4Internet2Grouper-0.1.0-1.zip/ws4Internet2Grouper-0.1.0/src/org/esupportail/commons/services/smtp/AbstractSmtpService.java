/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.smtp;

/**
 * An abstract implementation of SmtpService that does not support tests.
 */
public abstract class AbstractSmtpService implements SmtpService {

	/**
	 * @see org.esupportail.commons.services.smtp.SmtpService#supportsTest()
	 */
	public boolean supportsTest() {
		return false;
	}

	/**
	 * @see org.esupportail.commons.services.smtp.SmtpService#test()
	 */
	public void test() {
		throw new UnsupportedOperationException();
	}
	
}
