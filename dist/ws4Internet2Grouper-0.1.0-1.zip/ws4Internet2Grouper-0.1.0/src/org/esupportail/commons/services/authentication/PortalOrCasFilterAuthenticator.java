/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.authentication;

import java.io.Serializable;

import edu.yale.its.tp.cas.client.filter.CASFilter;

import org.esupportail.commons.services.logging.Logger;
import org.esupportail.commons.services.logging.LoggerImpl;
import org.esupportail.commons.utils.ContextUtils;

/** 
 * A class to resolve the current user depending on the installation:
 * - for portlet installations, rely on the portal,
 * - for servlet installations, rely on the CAS filter. 
 */
public class PortalOrCasFilterAuthenticator extends PortalAuthenticator implements Serializable {

	/**
	 * For serialize.
	 */
	private static final long serialVersionUID = 7666699752494305463L;

	/**
	 * A logger.
	 */
	private final Logger logger = new LoggerImpl(getClass());
	
	/**
	 * Bean constructor.
	 */
	public PortalOrCasFilterAuthenticator() {
		super();
	}

	/**
	 * @see org.esupportail.commons.services.authentication.PortalAuthenticator#getCurrentUserId()
	 */
	@Override
	public String getCurrentUserId() {
		if (logger.isDebugEnabled()) {
			logger.debug(getClass() + ".getCurrentUserId()");
		}
		String uid = super.getCurrentUserId();
		if (uid != null) {
			return uid;
		}
		if (!ContextUtils.isWeb()) {
			return null;
		}
		return (String) ContextUtils.getGlobalSessionAttribute(CASFilter.CAS_FILTER_USER);
	}

}
