/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.urlGeneration; 

import java.util.Map;

/**
 * An class that implements UrlGenerator and throws exceptions when called.
 */
public class NotSupportedUrlGeneratorImpl implements UrlGenerator {

	/**
	 * Bean constructor.
	 */
	protected NotSupportedUrlGeneratorImpl() {
		super();
	}
	
	/**
	 * @see org.esupportail.commons.services.urlGeneration.UrlGenerator#url(java.util.Map)
	 */
	public String url(
			final Map<String, String> params) {
		return url();
	}

	/**
	 * @see org.esupportail.commons.services.urlGeneration.UrlGenerator#url()
	 */
	public String url() {
		throw new UnsupportedOperationException("class " + getClass().getName() + "should never be called.");
	}

	/**
	 * @see org.esupportail.commons.services.urlGeneration.UrlGenerator#urlViaCas(java.util.Map)
	 */
	public String urlViaCas(
			final Map<String, String> params) {
		return url();
	}

	/**
	 * @see org.esupportail.commons.services.urlGeneration.UrlGenerator#urlViaCas()
	 */
	public String urlViaCas() {
		return url();
	}

}
