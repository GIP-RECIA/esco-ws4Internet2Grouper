/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.logging;

import java.util.List;

/**
 * The interface of logging classes.
 */
public interface Logger {

	/**
	 * This method should be called to prevent from performing expensive operations (such 
	 * as String concatenation) when the logger level is more than trace. 
	 * @return true if the TRACE level of the service is enabled.
	 */
	boolean isTraceEnabled();

	/**
	 * Log a StringBuffer as TRACE.
	 * @param sb a StringBuffer
	 */
	void trace(final StringBuffer sb);

	/**
	 * Log a string as TRACE.
	 * @param str a string
	 */
	void trace(final String str);

	/**
	 * Log an exception as TRACE.
	 * @param e an exception
	 */
	void trace(final Exception e);

	/**
	 * Log a string and an exception as TRACE.
	 * @param str a string
	 * @param e an exception
	 */
	void trace(final String str, final Exception e);

	/**
	 * Log a string buffer and an exception as TRACE.
	 * @param sb a string buffer
	 * @param e an exception
	 */
	void trace(final StringBuffer sb, final Exception e);

	/**
	 * Log a list of strings as TRACE.
	 * @param list
	 */
	void trace(final List<String> list);

	/**
	 * Log a list of strings and an exception as TRACE.
	 * @param list
	 * @param e
	 */
	void trace(final List<String> list, final Exception e);
	
	/**
	 * This method should be called to prevent from performing expensive operations (such 
	 * as String concatenation) when the logger level is more than debug. 
	 * @return true if the DEBUG level of the service is enabled.
	 */
	boolean isDebugEnabled();

	/**
	 * Log a string and a duration as DEBUG.
	 * @param str a string
	 * @param start the start time
	 */
	void debugTime(final String str, final long start);

	/**
	 * Log a StringBuffer as DEBUG.
	 * @param sb a StringBuffer
	 */
	void debug(final StringBuffer sb);

	/**
	 * Log a string as DEBUG.
	 * @param str a string
	 */
	void debug(final String str);

	/**
	 * Log an exception as DEBUG.
	 * @param e an exception
	 */
	void debug(final Exception e);

	/**
	 * Log a string and an exception as DEBUG.
	 * @param str a string
	 * @param e an exception
	 */
	void debug(final String str, final Exception e);

	/**
	 * Log a string buffer and an exception as DEBUG.
	 * @param sb a string buffer
	 * @param e an exception
	 */
	void debug(final StringBuffer sb, final Exception e);

	/**
	 * Log a list of strings as DEBUG.
	 * @param list
	 */
	void debug(final List<String> list);

	/**
	 * Log a list of strings and an exception as DEBUG.
	 * @param list
	 * @param e
	 */
	void debug(final List<String> list, final Exception e);

	/**
	 * Log a string as INFO.
	 * @param str a string
	 */
	void info(final String str);

	/**
	 * Log a StringBuffer as INFO.
	 * @param sb a StringBuffer
	 */
	void info(final StringBuffer sb);

	/**
	 * Log an exception as INFO.
	 * @param e an exception
	 */
	void info(final Exception e);

	/**
	 * Log a string and an exception as INFO.
	 * @param str a string
	 * @param e an exception
	 */
	void info(final String str, final Exception e);

	/**
	 * Log a string buffer and an exception as INFO.
	 * @param sb a string buffer
	 * @param e an exception
	 */
	void info(final StringBuffer sb, final Exception e);

	/**
	 * Log a list of strings as INFO.
	 * @param list
	 */
	void info(final List<String> list);

	/**
	 * Log a list of strings and an exception as INFO.
	 * @param list
	 * @param e
	 */
	void info(final List<String> list, final Exception e);

	/**
	 * Log a string as WARN.
	 * @param str a string
	 */
	void warn(final String str);

	/**
	 * Log a StringBuffer as WARN.
	 * @param sb a StringBuffer
	 */
	void warn(final StringBuffer sb);

	/**
	 * Log an exception as WARN.
	 * @param e an exception
	 */
	void warn(final Exception e);

	/**
	 * Log a string and an exception as WARN.
	 * @param str a string
	 * @param e an exception
	 */
	void warn(final String str, final Exception e);

	/**
	 * Log a string buffer and an exception as WARN.
	 * @param sb a string buffer
	 * @param e an exception
	 */
	void warn(final StringBuffer sb, final Exception e);

	/**
	 * Log a list of strings as WARN.
	 * @param list
	 */
	void warn(final List<String> list);

	/**
	 * Log a list of strings and an exception as WARN.
	 * @param list
	 * @param e
	 */
	void warn(final List<String> list, final Exception e);

	/**
	 * Log a string as ERROR.
	 * @param str a string
	 */
	void error(final String str);

	/**
	 * Log a StringBuffer as ERROR.
	 * @param sb a StringBuffer
	 */
	void error(final StringBuffer sb);

	/**
	 * Log an exception as ERROR.
	 * @param e an exception
	 */
	void error(final Exception e);

	/**
	 * Log a string and an exception as ERROR.
	 * @param str a string
	 * @param e an exception
	 */
	void error(final String str, final Exception e);

	/**
	 * Log a string buffer and an exception as ERROR.
	 * @param sb a string buffer
	 * @param e an exception
	 */
	void error(final StringBuffer sb, final Exception e);

	/**
	 * Log a list of strings as ERROR.
	 * @param list
	 */
	void error(final List<String> list);

	/**
	 * Log a list of strings and an exception as ERROR.
	 * @param list
	 * @param e
	 */
	void error(final List<String> list, final Exception e);

	/**
	 * Log a string as FATAL .
	 * @param str a string
	 */
	void fatal(final String str);

	/**
	 * Log a StringBuffer as FATAL.
	 * @param sb a StringBuffer
	 */
	void fatal(final StringBuffer sb);

	/**
	 * Log an exception as FATAL.
	 * @param e an exception
	 */
	void fatal(final Exception e);

	/**
	 * Log a string and an exception as FATAL.
	 * @param str a string
	 * @param e an exception
	 */
	void fatal(final String str, final Exception e);

	/**
	 * Log a string buffer and an exception as FATAL.
	 * @param sb a string buffer
	 * @param e an exception
	 */
	void fatal(final StringBuffer sb, final Exception e);

	/**
	 * Log a list of strings as FATAL.
	 * @param list
	 */
	void fatal(final List<String> list);

	/**
	 * Log a list of strings and an exception as FATAL.
	 * @param list
	 * @param e
	 */
	void fatal(final List<String> list, final Exception e);

}