/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.database.hibernate;

import java.util.HashMap;
import java.util.Map;

/**
 * A class to store the Hibernate all the connection data.
 */

public class HibernateThreadData {
	
	/**
	 * A list to store the connection data.
	 */
	private Map<String, HibernateThreadConnectionData> connectionMap;

	/**
	 * Bean constructor.
	 */
	HibernateThreadData() { 
		super();
		connectionMap = new HashMap<String, HibernateThreadConnectionData>();
	}
	
	/**
	 * Open the session.
	 * @param sessionFactoryBeanName
	 */
	void openSession(
			final String sessionFactoryBeanName) {
		HibernateThreadConnectionData connectionData = new HibernateThreadConnectionData(
				sessionFactoryBeanName);
		connectionMap.put(sessionFactoryBeanName, connectionData);
		connectionData.openSession();
	}

	/**
	 * Begin a transaction.
	 * @param sessionFactoryBeanName
	 */
	void beginTransaction(
			final String sessionFactoryBeanName) {
		HibernateThreadConnectionData connectionData = connectionMap.get(sessionFactoryBeanName);
		if (connectionData != null) {
			connectionData.beginTransaction();
		}
	}

	/**
	 * End a transaction.
	 * @param sessionFactoryBeanName
	 * @param commit 
	 */
	void endTransaction(
			final String sessionFactoryBeanName,
			final boolean commit) {
		HibernateThreadConnectionData connectionData = connectionMap.get(sessionFactoryBeanName);
		if (connectionData != null) {
			connectionData.endTransaction(commit);
		}
	}

	/**
	 * Close the session.
	 * @param sessionFactoryBeanName
	 */
	void closeSession(
			final String sessionFactoryBeanName) {
		HibernateThreadConnectionData connectionData = connectionMap.get(sessionFactoryBeanName);
		if (connectionData != null) {
			connectionData.closeSession();
			connectionMap.remove(sessionFactoryBeanName);
		}
	}

}
