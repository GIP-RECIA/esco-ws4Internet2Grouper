/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.authentication;

import edu.yale.its.tp.cas.client.filter.CASFilter;

import org.esupportail.commons.utils.ContextUtils;

/** 
 * A class to resolve the current user when authenticated by the CAS filter.
 */
public class CasFilterAuthenticator implements AuthenticationService {

	/**
	 * Bean constructor.
	 */
	public CasFilterAuthenticator() {
		super();
	}

	/**
	 * @see org.esupportail.commons.services.authentication.AuthenticationService#getCurrentUserId()
	 */
	public String getCurrentUserId() {
		if (!ContextUtils.isWeb()) {
			return null;
		}
		return (String) ContextUtils.getGlobalSessionAttribute(CASFilter.CAS_FILTER_USER);
	}

}
