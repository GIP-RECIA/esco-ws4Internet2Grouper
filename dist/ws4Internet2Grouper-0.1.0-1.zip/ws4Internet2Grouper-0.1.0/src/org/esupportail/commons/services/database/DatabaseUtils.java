/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.database;

import org.esupportail.commons.exceptions.ConfigException;
import org.esupportail.commons.services.logging.Logger;
import org.esupportail.commons.services.logging.LoggerImpl;
import org.esupportail.commons.utils.BeanUtils;

/**
 * A simple utility class to create/update the Hibernate database structures.
 */
public class DatabaseUtils {

	/**
	 * The name of the bean that holds thhe database manager store.
	 */
	public static final String DATABASE_MANAGER_STORE = "databaseManagerStore"; 
	
	/**
	 * A logger.
	 */
	private static final Logger LOG = new LoggerImpl(DatabaseUtils.class);
	
	/**
	 * A thread local to store the state.
	 */
	private static final ThreadLocal<Boolean> STATE = new ThreadLocal<Boolean>();
	
	/**
	 * The database manager store.
	 */
	private static DatabaseManagerStore databaseManagerStore;
	
    /**
     * Private constructor, no instanciation.
     */
    private DatabaseUtils() {
    	throw new UnsupportedOperationException();
    }
    
    /**
     * @return the database manager store.
     */
    private static DatabaseManagerStore getDatabaseManagerStore() {
    	if (databaseManagerStore == null) {
    		databaseManagerStore = (DatabaseManagerStore) BeanUtils.getBean(DATABASE_MANAGER_STORE);
    	}
    	return databaseManagerStore;
    }
    
    /**
     * @return true if the database connection have already been opened.
     */
    private static boolean isOpened() {
    	Boolean opened = STATE.get();
    	return opened != null;
    }
    
    /**
     * Set the database connection as opened/closed at thread-level.
     */
    private static void setOpened(final boolean opened) {
    	if (opened) {
    		STATE.set(Boolean.TRUE);
    	} else {
    		STATE.set(null);
    	}
    }
    
	/**
	 * Open the database connections (web mode).
	 */
	public static void open() {
		if (!isOpened()) {
			getDatabaseManagerStore().open();
			setOpened(true);
		}
	}

	/**
	 * Begin transactions (for transactionnal managers only).
	 */
	public static void begin() {
		databaseManagerStore.begin();
	}

	/**
	 * End current transactions.
	 * @param commit true to commit the current transaction, false to rollback
	 */
	public static void end(final boolean commit) {
		databaseManagerStore.end(commit);
	}

	/**
	 * Commit current transactions.
	 */
	public static void commit() {
		end(true);
	}

	/**
	 * Rollback current transactions.
	 */
	public static void rollback() {
		end(false);
	}

	/**
	 * Close the connections, rollback transactions if any.
	 */
	public static void close() {
		if (isOpened()) {
			databaseManagerStore.close();
			setOpened(false);
		}
	}

	/**
	 * Test the database.
	 * @throws ConfigException 
	 */
	public static void test() throws ConfigException {
		LOG.info("testing the databases, please wait...");
		getDatabaseManagerStore().test();
		LOG.info("done.");
	}
	
	/**
	 * Create the database.
	 * @throws ConfigException 
	 */
	public static void create() throws ConfigException {
		LOG.info("creating the databases, please wait...");
		getDatabaseManagerStore().create();
		LOG.info("done.");
	}
	
	/**
	 * Update the database.
	 * @throws ConfigException 
	 */
	public static void update() throws ConfigException {
		LOG.info("updating the database, please wait...");
		getDatabaseManagerStore().update();
		LOG.info("done.");
	}

}
