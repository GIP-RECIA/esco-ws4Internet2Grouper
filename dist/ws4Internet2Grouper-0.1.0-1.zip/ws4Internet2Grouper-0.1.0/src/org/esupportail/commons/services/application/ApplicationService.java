/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.application;


/** 
 * The interface of application services, which should inform about 
 * the current application (version, name...).
 */
public interface ApplicationService {
	
	/**
	 * @return the name of the application.
	 */
	String getName();
	
	/**
	 * @return the version.
	 */
	Version getVersion();

	/**
	 * @return the latest version.
	 */
	Version getLatestVersion();

	/**
	 * @return true for a quick start installation, false otherwise.
	 */
	boolean isQuickStart();

	/**
	 * @return the copyright of the application.
	 */
	String getCopyright();
	
	/**
	 * @return the vendor of the application.
	 */
	String getVendor();
	
}
