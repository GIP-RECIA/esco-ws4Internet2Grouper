/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.authentication;


/** 
 * The interface of the service used to get and set the current user's uid.
 */
public interface MutableAuthenticationService extends AuthenticationService {
	
	/**
	 * Set the user's Id.
	 * @param userId
	 */
	void setCurrentUserId(String userId);
	
	
}
