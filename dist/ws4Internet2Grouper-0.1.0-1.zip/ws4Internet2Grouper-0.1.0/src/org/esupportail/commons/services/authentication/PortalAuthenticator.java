/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.authentication;

import org.esupportail.commons.services.logging.Logger;
import org.esupportail.commons.services.logging.LoggerImpl;
import org.esupportail.commons.utils.ContextUtils;
import org.esupportail.commons.utils.HttpUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.StringUtils;

/** 
 * A class to resolve the current user when authenticated by the portal (works in portlet mode only).
 */
public class PortalAuthenticator implements AuthenticationService, InitializingBean {

	/**
	 * The default value for uidPortalAttribute.
	 */
	private static final String DEFAULT_UID_PORTAL_ATTRIBUTE = "uid";

	/**
	 * A logger.
	 */
	private final Logger logger = new LoggerImpl(getClass());

	/**
	 * The portal attribute that contains the uid (used in portlet mode only). 
	 */
	private String uidPortalAttribute;
	
	/**
	 * Bean constructor.
	 */
	public PortalAuthenticator() {
		super();
	}

	/**
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	public void afterPropertiesSet() throws Exception {
		if (!StringUtils.hasText(uidPortalAttribute)) {
			uidPortalAttribute = DEFAULT_UID_PORTAL_ATTRIBUTE;
			logger.warn(getClass() + ": no uidPortalAttribute set, using default [" 
					+ uidPortalAttribute + "]");
		}
	}
	
	/**
	 * @see org.esupportail.commons.services.authentication.AuthenticationService#getCurrentUserId()
	 */
	@SuppressWarnings("unchecked")
	public String getCurrentUserId() {
		if (!ContextUtils.isWeb()) {
			return null;
		}
		return (String) HttpUtils.getPortalPref(uidPortalAttribute);
	}

	/**
	 * @param uidPortalAttribute the uidPortalAttribute to set
	 */
	public void setUidPortalAttribute(final String uidPortalAttribute) {
		this.uidPortalAttribute = uidPortalAttribute;
	}

}
