/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.services.authentication;

import org.esupportail.commons.utils.ContextUtils;
import org.esupportail.commons.utils.HttpUtils;

/** 
 * A class to resolve the current user by calling getRemoteUser().
 */
public class RemoteUserAuthenticator implements AuthenticationService {

	/**
	 * Bean constructor.
	 */
	public RemoteUserAuthenticator() {
		super();
	}

	/**
	 * @see org.esupportail.commons.services.authentication.AuthenticationService#getCurrentUserId()
	 * call the getRemoteUser() on the current request.
	 */
	public String getCurrentUserId() {
		if (!ContextUtils.isWeb()) {
			return null;
		}
		return HttpUtils.getRemoteUser();
	}

}
