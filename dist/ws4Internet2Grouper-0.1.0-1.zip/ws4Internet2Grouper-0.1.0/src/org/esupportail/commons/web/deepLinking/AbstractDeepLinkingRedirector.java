/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.web.deepLinking;

import org.esupportail.commons.beans.AbstractI18nAwareBean;

/**
 * A deep linking redirector that does nothing.
 */
public abstract class AbstractDeepLinkingRedirector 
extends AbstractI18nAwareBean implements DeepLinkingRedirector {

	/**
	 * A parameter name.
	 */
	public static final String ENTER_PARAM = "enter";
	
	/**
	 * Bean constructor.
	 */
	public AbstractDeepLinkingRedirector() {
		super();
	}

	/**
	 * Print an error message when a parameter is missing.
	 * @param param
	 */
	protected void addErrorMessageMissingParameter(
			final String param) {
		addErrorMessage(null, "DEEP_LINKS.MESSAGE.MISSING_PARAMETER", param);
	}

	/**
	 * Print an error message when a parameter is invalid.
	 * @param param
	 */
	protected void addErrorMessageInvalidParameter(
			final String param,
			final String value) {
		addErrorMessage(null, "DEEP_LINKS.MESSAGE.INVALID_PARAMETER", param, value);
	}

}
