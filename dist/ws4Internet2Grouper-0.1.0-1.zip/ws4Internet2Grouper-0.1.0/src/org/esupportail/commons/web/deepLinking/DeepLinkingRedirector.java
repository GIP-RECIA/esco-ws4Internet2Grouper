/**
 * ESUP-Portail Commons - Copyright (c) 2006 ESUP-Portail consortium
 * http://sourcesup.cru.fr/projects/esup-commons
 */
package org.esupportail.commons.web.deepLinking;

import java.util.Map;

/**
 * The interface of a page redirector, used for deep linking.
 */
public interface DeepLinkingRedirector {
	
	/**
	 * @param params the deep link parameters
	 * @return the view to redirect to, or null for the default view. 
	 */
	String redirect(
			final Map<String, String> params);

}
