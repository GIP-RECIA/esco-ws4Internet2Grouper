package org.fckfaces.taglib.html;

import javax.faces.component.UIComponent;

import org.apache.myfaces.taglib.html.HtmlInputTextareaTag;
import org.fckfaces.util.Tags;

/**
 * 
 * @author srecinto
 *
 */
public class FCKFaceEditorTag extends HtmlInputTextareaTag {
	/**
	 * 
	 */
	public static final String COMPONENT_TYPE = "org.fckfaces.Editor";
	/**
	 * 
	 */
	public static final String RENDERER_TYPE = "org.fckfaces.EditorRenderer";
	
	/**
	 * 
	 */
	private String toolbarSet;
	/**
	 * 
	 */
	private String height;
	/**
	 * 
	 */
	private String width;
	
	/**
	 * Bean constructor.
	 */
	public FCKFaceEditorTag() {
		super();
	}

	/**
	 * @see org.apache.myfaces.taglib.html.HtmlInputTextareaTag#getComponentType()
	 */
	@Override
	public String getComponentType() { 
		return COMPONENT_TYPE; 
	}
	
	/**
	 * @see org.apache.myfaces.taglib.html.HtmlInputTextareaTag#getRendererType()
	 */
	@Override
	public String getRendererType() { 
		return RENDERER_TYPE;
	}
	
	/**
	 * @see org.apache.myfaces.shared_impl.taglib.html.HtmlInputTextareaTagBase#setProperties(
	 * javax.faces.component.UIComponent)
	 */
	@Override
	protected void setProperties(final UIComponent component) {
	    super.setProperties(component);
	    Tags.setString(component, "toolbarSet", toolbarSet);
	}
	
	/**
	 * @see org.apache.myfaces.shared_impl.taglib.html.HtmlInputTextareaTagBase#release()
	 */
	@Override
	public void release() {
	    super.release();
	    toolbarSet = null;
	}

	/**
	 * @return x
	 */
	public String getToolbarSet() {
		return toolbarSet;
	}

	/**
	 * @param toolbarSet
	 */
	public void setToolbarSet(final String toolbarSet) {
		this.toolbarSet = toolbarSet;
	}

	/**
	 * @return x
	 */
	public String getHeight() {
		return height;
	}

	/**
	 * @param height
	 */
	public void setHeight(final String height) {
		this.height = height;
	}

	/**
	 * @return x
	 */
	public String getWidth() {
		return width;
	}

	/**
	 * @param width
	 */
	public void setWidth(final String width) {
		this.width = width;
	}
}
