package org.fckfaces.util;

import java.io.Serializable;

import javax.faces.application.Application;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.webapp.UIComponentTag;

/**
 * 
 */
public class Tags {

	/**
	 * Bean constructor.
	 */
	private Tags() {
		throw new UnsupportedOperationException();
	}

	/**
	 * @param component
	 * @param attributeName
	 * @param attributeValue
	 */
	@SuppressWarnings("unchecked")
	public static void setString(
			final UIComponent component, 
			final String attributeName,
			final String attributeValue) {
		if (attributeValue == null) {
			return;
		}
		if (UIComponentTag.isValueReference(attributeValue)) {
			setValueBinding(component, attributeName, attributeValue);
		} else {
			component.getAttributes().put(attributeName, attributeValue);
		}
	}

	/**
	 * @param component
	 * @param attributeName
	 * @param attributeValue
	 */
	@SuppressWarnings("unchecked")
	public static void setInteger(
			final UIComponent component, 
			final String attributeName, 
			final String attributeValue) {
		if (attributeValue == null) {
			return;
		}
		if (UIComponentTag.isValueReference(attributeValue)) {
			setValueBinding(component, attributeName, attributeValue);
		} else { 
			component.getAttributes().put(attributeName, new Integer(attributeValue));
		}
	}

	/**
	 * @param component
	 * @param attributeName
	 * @param attributeValue
	 */
	@SuppressWarnings("unchecked")
	public static void setBoolean(
			final UIComponent component, 
			final String attributeName, 
			final String attributeValue) {
		if (attributeValue == null) {
			return;
		}
		if (UIComponentTag.isValueReference(attributeValue)) {
			setValueBinding(component, attributeName, attributeValue);
		} else { 
			component.getAttributes().put(attributeName, new Boolean(attributeValue));
		}
	}

	/**
	 * @param component
	 * @param attributeName
	 * @param attributeValue
	 */
	public static void setValueBinding(
			final UIComponent component, 
			final String attributeName,
			final String attributeValue) {
		FacesContext context = FacesContext.getCurrentInstance();
		Application app = context.getApplication();
		ValueBinding vb = app.createValueBinding(attributeValue);
		component.setValueBinding(attributeName, vb);
	}

	/**
	 * @param component
	 * @param attributeValue
	 */
	public static void setActionListener(
			final UIComponent component, 
			final String attributeValue) {
		setMethodBinding(component, "actionListener", attributeValue,
				new Class[] { 
				ActionEvent.class, 
				});      
	}

	/**
	 * @param component
	 * @param attributeValue
	 */
	public static void setValueChangeListener(
			final UIComponent component, 
			final String attributeValue) {
		setMethodBinding(component, "valueChangeListener", attributeValue,
				new Class[] {
				ValueChangeEvent.class,
				});      
	}

	/**
	 * @param component
	 * @param attributeValue
	 */
	public static void setValidator(
			final UIComponent component, 
			final String attributeValue) {
		setMethodBinding(component, "validator", attributeValue,
				new Class[] { 
				FacesContext.class, 
				UIComponent.class, 
				Object.class, });      
	}

	/**
	 * @param component
	 * @param attributeValue
	 */
	@SuppressWarnings("unchecked")
	public static void setAction(
			final UIComponent component, 
			final String attributeValue) {
		if (attributeValue == null) {
			return;
		}
		if (UIComponentTag.isValueReference(attributeValue)) {
			setMethodBinding(component, "action", attributeValue,
					new Class[] {});
		} else {
			MethodBinding mb = new ActionMethodBinding(attributeValue);
			component.getAttributes().put("action", mb);         
		}
	}

	/**
	 * @param component
	 * @param attributeName
	 * @param attributeValue
	 * @param paramTypes
	 */
	@SuppressWarnings("unchecked")
	public static void setMethodBinding(
			final UIComponent component, 
			final String attributeName,
			final String attributeValue, 
			final Class[] paramTypes) {
		if (attributeValue == null) {
			return;
		}
		if (UIComponentTag.isValueReference(attributeValue)) {
			FacesContext context = FacesContext.getCurrentInstance();
			Application app = context.getApplication();
			MethodBinding mb = app.createMethodBinding(attributeValue, paramTypes);
			component.getAttributes().put(attributeName, mb);
		}
	}     

	/**
	 * 
	 */
	private static class ActionMethodBinding 
	extends MethodBinding 
	implements Serializable  {      
		/**
		 * 
		 */
		private static final long serialVersionUID = 6027374557161316454L;
		/**
		 * 
		 */
		private String result;

		/**
		 * Bean constructor.
		 * @param result
		 */
		public ActionMethodBinding(
				final String result) { 
			this.result = result; 
		}      
		/**
		 * @see javax.faces.el.MethodBinding#invoke(javax.faces.context.FacesContext, java.lang.Object[])
		 */
		@Override
		public Object invoke(
				final FacesContext context, 
				final Object [] params) {
			return result;
		}
		/**
		 * @see javax.faces.el.MethodBinding#getExpressionString()
		 */
		@Override
		public String getExpressionString() { 
			return result; 
		}
		/**
		 * @see javax.faces.el.MethodBinding#getType(javax.faces.context.FacesContext)
		 */
		@SuppressWarnings("unchecked")
		@Override
		public Class getType(
				final FacesContext context) { 
			return String.class; 
		}
	}
}
